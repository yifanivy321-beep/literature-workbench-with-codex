from __future__ import annotations

import asyncio
import hashlib
import json
import re
import shutil
import sqlite3
import subprocess
import tempfile
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import fitz
from codex_adapter import CodexCliAdapter, create_adapter
from codex_rpc import CodexRpc, RpcError
from fastapi import BackgroundTasks, FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parent
DATA = ROOT / ".workbench-data"
FILES = DATA / "documents"
DB_PATH = DATA / "workbench.sqlite3"
MAX_PDF_BYTES = 120 * 1024 * 1024
NOW = lambda: datetime.now(timezone.utc).isoformat(timespec="seconds")


class WorkbenchConnection(sqlite3.Connection):
    def __exit__(self, *args):
        try: return super().__exit__(*args)
        finally: self.close()

def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, factory=WorkbenchConnection)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    DATA.mkdir(exist_ok=True)
    FILES.mkdir(exist_ok=True)
    if DB_PATH.exists():
        with sqlite3.connect(DB_PATH, factory=WorkbenchConnection) as source:
            if source.execute('PRAGMA user_version').fetchone()[0] < 3:
                folder = DATA / 'backups'
                folder.mkdir(exist_ok=True)
                with sqlite3.connect(folder / f'pre-v3-{time.time_ns()}.sqlite3', factory=WorkbenchConnection) as target:
                    source.backup(target)
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS documents (
          id TEXT PRIMARY KEY, file_path TEXT NOT NULL, file_name TEXT NOT NULL,
          file_hash TEXT NOT NULL UNIQUE, file_size INTEGER NOT NULL, page_count INTEGER NOT NULL,
          language TEXT, parse_status TEXT NOT NULL, ocr_status TEXT NOT NULL,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          parse_revision INTEGER NOT NULL DEFAULT 1, pipeline_version TEXT NOT NULL DEFAULT '0.3.0',
          quality_status TEXT NOT NULL DEFAULT 'unknown'
        );
        CREATE TABLE IF NOT EXISTS pages (
          id INTEGER PRIMARY KEY, document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
          page_number INTEGER NOT NULL, raw_text TEXT NOT NULL, ocr_text TEXT NOT NULL DEFAULT '',
          effective_text TEXT NOT NULL DEFAULT '', text_source TEXT NOT NULL, parse_confidence REAL NOT NULL,
          page_kind TEXT NOT NULL DEFAULT 'unknown', ocr_status TEXT NOT NULL DEFAULT 'not_needed',
          quality_reason TEXT NOT NULL DEFAULT '', error_code TEXT NOT NULL DEFAULT '', error_message TEXT NOT NULL DEFAULT '',
          UNIQUE(document_id,page_number)
        );
        CREATE TABLE IF NOT EXISTS text_blocks (
          id INTEGER PRIMARY KEY, page_id INTEGER NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
          block_index INTEGER NOT NULL, block_type TEXT NOT NULL, text TEXT NOT NULL,
          bbox TEXT NOT NULL, confidence REAL NOT NULL, revision INTEGER NOT NULL DEFAULT 1,
          source TEXT NOT NULL DEFAULT 'native', reading_order INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS conversations (
          id TEXT PRIMARY KEY, document_id TEXT REFERENCES documents(id) ON DELETE SET NULL,
          title TEXT NOT NULL, context_mode TEXT NOT NULL DEFAULT 'selection',
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS messages (
          id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
          role TEXT NOT NULL, content TEXT NOT NULL, context_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL,
          requested_model TEXT, actual_model TEXT, adapter TEXT, generation_status TEXT NOT NULL DEFAULT 'saved', parse_revision INTEGER
        );
        CREATE TABLE IF NOT EXISTS citations (
          id INTEGER PRIMARY KEY, message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
          document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
          page_number INTEGER NOT NULL, quote TEXT NOT NULL, bbox TEXT NOT NULL DEFAULT '[]', confidence REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS annotations (
          id TEXT PRIMARY KEY, document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
          page_number INTEGER NOT NULL, selected_text TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
          color TEXT NOT NULL DEFAULT 'amber', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS bookmarks (
          id TEXT PRIMARY KEY, document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
          page_number INTEGER NOT NULL, label TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
          UNIQUE(document_id,page_number)
        );
        CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS import_jobs (id TEXT PRIMARY KEY, status TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0, message TEXT NOT NULL, document_id TEXT, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS parse_jobs (id TEXT PRIMARY KEY, document_id TEXT NOT NULL, scope TEXT NOT NULL, stage TEXT NOT NULL, total_pages INTEGER NOT NULL DEFAULT 0, completed_pages INTEGER NOT NULL DEFAULT 0, failed_pages INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL, revision INTEGER NOT NULL, error_json TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_pages_document ON pages(document_id,page_number);
        CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id,created_at);
        """)
        # Versioned additive migration for databases created by 0.2.x.
        migrations = {
            'documents': [('parse_revision','INTEGER NOT NULL DEFAULT 1'),('pipeline_version',"TEXT NOT NULL DEFAULT '0.3.0'"),('quality_status',"TEXT NOT NULL DEFAULT 'unknown'")],
            'pages': [('effective_text',"TEXT NOT NULL DEFAULT ''"),('page_kind',"TEXT NOT NULL DEFAULT 'unknown'"),('ocr_status',"TEXT NOT NULL DEFAULT 'not_needed'"),('quality_reason',"TEXT NOT NULL DEFAULT ''"),('error_code',"TEXT NOT NULL DEFAULT ''"),('error_message',"TEXT NOT NULL DEFAULT ''")],
            'text_blocks': [('revision','INTEGER NOT NULL DEFAULT 1'),('source',"TEXT NOT NULL DEFAULT 'native'"),('reading_order','INTEGER NOT NULL DEFAULT 0')],
            'messages': [('requested_model','TEXT'),('actual_model','TEXT'),('adapter','TEXT'),('generation_status',"TEXT NOT NULL DEFAULT 'saved'"),('parse_revision','INTEGER')]
        }
        for table, fields in migrations.items():
            existing = {r[1] for r in conn.execute(f'PRAGMA table_info({table})')}
            for name, typ in fields:
                if name not in existing: conn.execute(f'ALTER TABLE {table} ADD COLUMN {name} {typ}')
        conn.execute("UPDATE pages SET effective_text=CASE WHEN text_source='ocr' THEN ocr_text ELSE raw_text END WHERE effective_text='' AND page_kind='unknown' AND quality_reason=''")


def detect_codex() -> dict[str, Any]:
    configured = None
    with db() as conn:
        value = conn.execute("SELECT value FROM settings WHERE key='codex.cli_path'").fetchone()
        if value: configured = value[0]
    adapter = create_adapter(configured or None)
    result = adapter.probe()
    result['models_endpoint'] = '/api/codex/models'
    return result


def parse_pdf(path, doc_id, file_name, digest, size, job_id=None):
    from parsing_store import parse_document
    return parse_document(path, doc_id, file_name, digest, size, job_id=job_id)


def process_import(job_id: str, path: Path, doc_id: str, name: str, digest: str, size: int) -> None:
    try:
        result = parse_pdf(path, doc_id, name, digest, size, job_id)
        with db() as conn:
            conn.execute("UPDATE import_jobs SET status='completed',progress=100,message='解析完成',document_id=? WHERE id=?", (doc_id, job_id))
    except HTTPException as exc:
        with db() as conn:
            conn.execute("UPDATE import_jobs SET status='failed',message=? WHERE id=?", (str(exc.detail), job_id))
    except Exception as exc:
        with db() as conn:
            conn.execute("UPDATE import_jobs SET status='failed',message=? WHERE id=?", (f"解析失败：{exc}", job_id))


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    from parsing_store import migrate_and_audit
    migrate_and_audit()
    yield


app = FastAPI(title="本地文献阅读工作台", version="0.4.0", lifespan=lifespan)


@app.get("/api/health")
def health():
    return {"ok": True, "codex": detect_codex(), "ocr": __import__("pdf_pipeline").engine_info(),
            "database": str(DB_PATH), "storage": "local"}


@app.get("/api/diagnostics")
def diagnostics():
    with db() as conn:
        documents = conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
        conversations = conn.execute("SELECT COUNT(*) FROM conversations").fetchone()[0]
        failed_imports = conn.execute("SELECT COUNT(*) FROM import_jobs WHERE status='failed'").fetchone()[0]
    return {"application": app.version, "service": "available", "codex": detect_codex(),
            "ocr": __import__("pdf_pipeline").engine_info(),
            "storage": "local SQLite", "document_count": documents, "conversation_count": conversations,
            "failed_imports": failed_imports, "database_size_bytes": DB_PATH.stat().st_size if DB_PATH.exists() else 0}


@app.post("/api/documents")
async def upload_document(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    name = Path(file.filename or "document.pdf").name
    if not name.lower().endswith(".pdf") or (file.content_type and file.content_type not in ("application/pdf", "application/octet-stream")):
        raise HTTPException(415, "文件格式不支持，请选择 PDF")
    content = await file.read(MAX_PDF_BYTES + 1)
    if len(content) > MAX_PDF_BYTES:
        raise HTTPException(413, f"文献超过 {MAX_PDF_BYTES // (1024*1024)} MB 限制")
    digest = hashlib.sha256(content).hexdigest()
    with db() as conn:
        existing = conn.execute("SELECT id,file_name,page_count,parse_status,ocr_status,parse_revision FROM documents WHERE file_hash=?", (digest,)).fetchone()
    if existing:
        return {"duplicate": True, **dict(existing)}
    doc_id = str(uuid.uuid4())
    path = FILES / f"{doc_id}.pdf"
    path.write_bytes(content)
    job_id = str(uuid.uuid4())
    with db() as conn:
        conn.execute("INSERT INTO import_jobs(id,status,progress,message,created_at) VALUES(?,?,?,?,?)", (job_id, "running", 1, "已接收文件，准备解析", NOW()))
    background_tasks.add_task(process_import, job_id, path, doc_id, name, digest, len(content))
    return JSONResponse(status_code=202, content={"job_id": job_id, "file_name": name, "status": "running"})


@app.get("/api/jobs/{job_id}")
def import_job(job_id: str):
    with db() as conn:
        row = conn.execute("SELECT * FROM import_jobs WHERE id=?", (job_id,)).fetchone()
    if not row:
        with db() as conn: row = conn.execute('SELECT * FROM parse_jobs WHERE id=?', (job_id,)).fetchone()
        if not row: raise HTTPException(404, "任务不存在")
    result = dict(row)
    if result["document_id"]:
        with db() as conn:
            doc = conn.execute("SELECT id,file_name,file_hash,file_size,page_count,language,parse_status,ocr_status,created_at,updated_at,parse_revision,quality_status FROM documents WHERE id=?", (result["document_id"],)).fetchone()
        result["document"] = dict(doc) if doc else None
    return result


@app.get("/api/documents")
def list_documents():
    with db() as conn:
        rows = conn.execute("SELECT id,file_name,file_hash,file_size,page_count,language,parse_status,ocr_status,created_at,updated_at,parse_revision,quality_status FROM documents ORDER BY updated_at DESC").fetchall()
    result = []
    for row in rows:
        item = dict(row)
        item["file_available"] = (FILES / f"{item['id']}.pdf").exists()
        result.append(item)
    return result


@app.get("/api/documents/{doc_id}")
def document_info(doc_id: str):
    with db() as conn:
        row = conn.execute("SELECT id,file_name,file_hash,file_size,page_count,language,parse_status,ocr_status,created_at,updated_at,parse_revision,quality_status FROM documents WHERE id=?", (doc_id,)).fetchone()
    if not row:
        raise HTTPException(404, "未找到文献")
    result = dict(row)
    with db() as conn:
        stats = conn.execute("SELECT COUNT(*) total,SUM(CASE WHEN length(effective_text)>0 AND error_code='' THEN 1 ELSE 0 END) usable,SUM(CASE WHEN page_kind IN ('blank','non_body') AND error_code='' THEN 1 ELSE 0 END) non_body,SUM(CASE WHEN error_code<>'' THEN 1 ELSE 0 END) failed FROM pages WHERE document_id=?", (doc_id,)).fetchone()
    result['page_stats'] = dict(stats)
    return result


@app.get("/api/documents/{doc_id}/file")
def document_file(doc_id: str):
    with db() as conn:
        row = conn.execute("SELECT file_path,file_name FROM documents WHERE id=?", (doc_id,)).fetchone()
    if not row or not Path(row["file_path"]).exists():
        raise HTTPException(404, "原始 PDF 不存在，请重新导入")
    return FileResponse(row["file_path"], media_type="application/pdf", filename=row["file_name"], content_disposition_type="inline")


@app.get("/api/documents/{doc_id}/pages/{page_number}")
def page_content(doc_id: str, page_number: int):
    with db() as conn:
        row = conn.execute("SELECT p.*,d.file_name FROM pages p JOIN documents d ON d.id=p.document_id WHERE p.document_id=? AND p.page_number=?", (doc_id, page_number)).fetchone()
    if not row:
        raise HTTPException(404, "页码不存在")
    result = dict(row)
    with db() as conn:
        result['blocks'] = [dict(r) for r in conn.execute('SELECT * FROM text_blocks WHERE page_id=? ORDER BY reading_order', (row['id'],))]
        result['parse_revision'] = conn.execute('SELECT parse_revision FROM documents WHERE id=?',(doc_id,)).fetchone()[0]
    return result


class ConversationCreate(BaseModel):
    document_id: str | None = None
    title: str = "新会话"


@app.post("/api/conversations")
def create_conversation(body: ConversationCreate):
    conversation_id = str(uuid.uuid4())
    now = NOW()
    with db() as conn:
        if body.document_id and not conn.execute("SELECT 1 FROM documents WHERE id=?", (body.document_id,)).fetchone():
            raise HTTPException(404, "文献不存在")
        conn.execute("INSERT INTO conversations(id,document_id,title,context_mode,created_at,updated_at) VALUES(?,?,?,?,?,?)", (conversation_id, body.document_id, body.title, "selection", now, now))
    return {"id": conversation_id, "document_id": body.document_id, "title": body.title, "created_at": now}


@app.get("/api/conversations")
def list_conversations(document_id: str | None = None):
    with db() as conn:
        if document_id:
            rows = conn.execute("SELECT * FROM conversations WHERE document_id=? ORDER BY updated_at DESC", (document_id,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM conversations ORDER BY updated_at DESC").fetchall()
    return [dict(row) for row in rows]


@app.get("/api/conversations/{conversation_id}/messages")
def conversation_messages(conversation_id: str):
    with db() as conn:
        rows = conn.execute("SELECT * FROM messages WHERE conversation_id=? ORDER BY created_at", (conversation_id,)).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["citations"] = [dict(c) for c in conn.execute("SELECT page_number AS page,quote,confidence,revision,block_id,source_kind,validation_status,page_label,bbox FROM citations WHERE message_id=?", (row["id"],)).fetchall()]
            result.append(item)
    return result


class ConversationRename(BaseModel):
    title: str


@app.patch("/api/conversations/{conversation_id}")
def rename_conversation(conversation_id: str, body: ConversationRename):
    title = body.title.strip()
    if not title or len(title) > 120:
        raise HTTPException(400, "会话名称须为 1 到 120 个字符")
    with db() as conn:
        cur = conn.execute("UPDATE conversations SET title=?,updated_at=? WHERE id=?", (title, NOW(), conversation_id))
        if not cur.rowcount:
            raise HTTPException(404, "会话不存在")
    return {"id": conversation_id, "title": title}


@app.delete("/api/conversations/{conversation_id}")
def delete_conversation(conversation_id: str):
    with db() as conn:
        cur = conn.execute("DELETE FROM conversations WHERE id=?", (conversation_id,))
        if not cur.rowcount:
            raise HTTPException(404, "会话不存在")
    return {"deleted": True}


@app.get("/api/conversations/{conversation_id}/export.md")
def export_conversation(conversation_id: str):
    with db() as conn:
        conv = conn.execute("SELECT title FROM conversations WHERE id=?", (conversation_id,)).fetchone()
        if not conv:
            raise HTTPException(404, "会话不存在")
        messages = conn.execute("SELECT id,role,content,created_at FROM messages WHERE conversation_id=? ORDER BY created_at", (conversation_id,)).fetchall()
        lines = [f"# {conv['title']}", "", f"导出时间：{NOW()}", ""]
        for message in messages:
            label = "用户" if message["role"] == "user" else "Codex"
            lines.extend([f"## {label}", "", message["content"], ""])
            for citation in conn.execute("SELECT page_number,quote FROM citations WHERE message_id=? ORDER BY page_number", (message["id"],)).fetchall():
                lines.append(f"> 第 {citation['page_number']} 页：{citation['quote']}")
                lines.append("")
    return Response("\n".join(lines), media_type="text/markdown; charset=utf-8", headers={"Content-Disposition": f"attachment; filename=conversation-{conversation_id[:8]}.md"})


@app.get("/api/search")
def search(document_id: str, q: str):
    term = q.strip()
    if not term or len(term) > 200:
        raise HTTPException(400, "请输入 1 到 200 字符的搜索词")
    with db() as conn:
        rows = conn.execute("SELECT page_number,effective_text,text_source,parse_confidence FROM pages WHERE document_id=? AND instr(lower(effective_text),lower(?))>0 ORDER BY page_number LIMIT 100", (document_id, term)).fetchall()
    results = []
    for r in rows:
        start = max(0, r['effective_text'].lower().find(term.lower()) - 160)
        results.append({'page_number': r['page_number'], 'snippet': ('…' if start else '') + r['effective_text'][start:start+900], 'text_source': r['text_source'], 'confidence': r['parse_confidence']})
    return results


@app.delete("/api/documents/{doc_id}")
def delete_document(doc_id: str):
    with db() as conn:
        row = conn.execute("SELECT file_path FROM documents WHERE id=?", (doc_id,)).fetchone()
        if not row:
            raise HTTPException(404, "文献不存在")
        conn.execute("DELETE FROM conversations WHERE document_id=?", (doc_id,))
        conn.execute("DELETE FROM documents WHERE id=?", (doc_id,))
    Path(row["file_path"]).unlink(missing_ok=True)
    return {"deleted": True}


class AnnotationCreate(BaseModel):
    document_id: str
    page_number: int
    selected_text: str
    note: str = ""
    color: str = "amber"


@app.post("/api/annotations")
def create_annotation(body: AnnotationCreate):
    if not body.selected_text.strip() or body.page_number < 1:
        raise HTTPException(400, "批注需要选中文本和有效页码")
    annotation_id = str(uuid.uuid4())
    with db() as conn:
        if not conn.execute("SELECT 1 FROM pages WHERE document_id=? AND page_number=?", (body.document_id, body.page_number)).fetchone():
            raise HTTPException(404, "文献页码不存在")
        conn.execute("INSERT INTO annotations VALUES(?,?,?,?,?,?,?)", (annotation_id, body.document_id, body.page_number, body.selected_text, body.note, body.color, NOW()))
    return {"id": annotation_id, "document_id": body.document_id, "page_number": body.page_number}


@app.get("/api/documents/{doc_id}/annotations")
def list_annotations(doc_id: str):
    with db() as conn:
        return [dict(row) for row in conn.execute("SELECT * FROM annotations WHERE document_id=? ORDER BY page_number,created_at", (doc_id,)).fetchall()]


@app.delete("/api/annotations/{annotation_id}")
def delete_annotation(annotation_id: str):
    with db() as conn:
        cur = conn.execute("DELETE FROM annotations WHERE id=?", (annotation_id,))
        if not cur.rowcount:
            raise HTTPException(404, "批注不存在")
    return {"deleted": True}


class BookmarkCreate(BaseModel):
    document_id: str
    page_number: int
    label: str = ""


@app.get("/api/documents/{doc_id}/bookmarks")
def list_bookmarks(doc_id: str):
    with db() as conn:
        return [dict(row) for row in conn.execute("SELECT * FROM bookmarks WHERE document_id=? ORDER BY page_number", (doc_id,)).fetchall()]


@app.post("/api/bookmarks")
def create_bookmark(body: BookmarkCreate):
    bookmark_id = str(uuid.uuid4())
    with db() as conn:
        if not conn.execute("SELECT 1 FROM pages WHERE document_id=? AND page_number=?", (body.document_id, body.page_number)).fetchone():
            raise HTTPException(404, "文献页码不存在")
        conn.execute("INSERT INTO bookmarks(id,document_id,page_number,label,created_at) VALUES(?,?,?,?,?) ON CONFLICT(document_id,page_number) DO UPDATE SET label=excluded.label", (bookmark_id, body.document_id, body.page_number, body.label, NOW()))
        row = conn.execute("SELECT * FROM bookmarks WHERE document_id=? AND page_number=?", (body.document_id, body.page_number)).fetchone()
    return dict(row)


@app.delete("/api/bookmarks/{bookmark_id}")
def delete_bookmark(bookmark_id: str):
    with db() as conn:
        cur = conn.execute("DELETE FROM bookmarks WHERE id=?", (bookmark_id,))
        if not cur.rowcount:
            raise HTTPException(404, "书签不存在")
    return {"deleted": True}


class SettingUpdate(BaseModel):
    value: str


@app.put("/api/settings/{key}")
def set_setting(key: str, body: SettingUpdate):
    if len(key) > 80 or len(body.value) > 4000:
        raise HTTPException(400, "设置值过长")
    with db() as conn:
        conn.execute("INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at", (key, body.value, NOW()))
    return {"key": key, "value": body.value}


@app.get("/api/settings")
def get_settings():
    with db() as conn:
        return {row["key"]: row["value"] for row in conn.execute("SELECT key,value FROM settings").fetchall()}


from workbench_api import install_routes
install_routes(app)
from library_api import install_library_routes
install_library_routes(app)
app.mount("/vendor", StaticFiles(directory=ROOT / "vendor"), name="vendor")
@app.get("/")
def index_page(): return FileResponse(ROOT / "index.html")
@app.get("/app.js")
def app_script(): return FileResponse(ROOT / "app.js", media_type="application/javascript")
@app.get("/reader.js")
def reader_script(): return FileResponse(ROOT / "reader.js", media_type="application/javascript")
@app.get('/workspace.js')
def workspace_script(): return FileResponse(ROOT / 'workspace.js', media_type='application/javascript')
@app.get("/styles.css")
def app_styles(): return FileResponse(ROOT / "styles.css", media_type="text/css")
@app.get('/qa/render')
def render_fixture(): return FileResponse(ROOT / 'docs' / 'render-fixture.html')
