"""Backup-before-migration and atomic revision activation without deleting source data."""
from __future__ import annotations
import json
import sqlite3
import time
import uuid
from pathlib import Path
import fitz
import pdf_pipeline as pipeline

def migrate_and_audit():
    import server as s
    with s.db() as conn:
        columns={r[1] for r in conn.execute('PRAGMA table_info(pages)')}
        fields={'page_width':'REAL DEFAULT 0','page_height':'REAL DEFAULT 0','rotation':'INTEGER DEFAULT 0',
            'image_coverage':'REAL DEFAULT 0','native_body_chars':'INTEGER DEFAULT 0','engine':"TEXT DEFAULT ''",'engine_version':"TEXT DEFAULT ''",'page_label':"TEXT DEFAULT ''",'revision':'INTEGER DEFAULT 1'}
        if any(k not in columns for k in fields):
            folder=s.DATA/'backups'; folder.mkdir(exist_ok=True)
            backup=sqlite3.connect(folder/f'migration-{time.time_ns()}.sqlite3')
            conn.backup(backup); backup.close()
        for name,typ in fields.items():
            if name not in columns: conn.execute(f'ALTER TABLE pages ADD COLUMN {name} {typ}')
        conv_cols={r[1] for r in conn.execute('PRAGMA table_info(conversations)')}
        for name in ('model','reasoning_effort'):
            if name not in conv_cols: conn.execute(f'ALTER TABLE conversations ADD COLUMN {name} TEXT')
        block_cols={r[1] for r in conn.execute('PRAGMA table_info(text_blocks)')}
        if 'paragraph_key' not in block_cols:conn.execute("ALTER TABLE text_blocks ADD COLUMN paragraph_key TEXT DEFAULT ''")
        citation_cols={r[1] for r in conn.execute('PRAGMA table_info(citations)')}
        for name,typ in {'revision':'INTEGER','block_id':'INTEGER','source_kind':"TEXT DEFAULT 'text_quote'",'validation_status':"TEXT DEFAULT 'legacy'",'page_label':"TEXT DEFAULT ''"}.items():
            if name not in citation_cols:conn.execute(f'ALTER TABLE citations ADD COLUMN {name} {typ}')
        conn.execute('CREATE TABLE IF NOT EXISTS page_revisions(document_id TEXT,page_number INTEGER,revision INTEGER,payload TEXT NOT NULL,PRIMARY KEY(document_id,page_number,revision))')
        conn.execute('PRAGMA user_version=3')
        for doc in conn.execute('SELECT * FROM documents').fetchall():
            if doc['pipeline_version']==pipeline.VERSION: continue
            with fitz.open(doc['file_path']) as pdf:
                needs = any(pipeline.analyze(page)['needs_ocr'] for page in pdf)
            if needs:
                conn.execute("UPDATE documents SET parse_status='needs_ocr',quality_status='needs_reparse' WHERE id=?",(doc['id'],))
                conn.execute("UPDATE pages SET effective_text='',quality_reason='legacy_parser_requires_reparse' WHERE document_id=?",(doc['id'],))
        conn.execute("UPDATE parse_jobs SET status='interrupted',stage='interrupted; retry available' WHERE status IN ('running','queued')")

def parse_document(path,doc_id,name,digest,size,job_id=None,scope='all',page_number=1,force=False,resume=False):
    import server as s
    info=pipeline.engine_info()
    with s.db() as conn:
        old=conn.execute('SELECT * FROM documents WHERE id=?',(doc_id,)).fetchone()
        revision=old['parse_revision']+1 if old else 1
        existing_job=conn.execute('SELECT status FROM parse_jobs WHERE id=?',(job_id,)).fetchone()
        if existing_job and existing_job[0]=='cancelled':return {'id':doc_id,'cancelled':True}
        conn.execute("UPDATE parse_jobs SET status='running',stage='render',revision=? WHERE id=?",(revision,job_id))
    results=[]
    def cancelled():
        if not job_id:return False
        with s.db() as conn:
            r=conn.execute('SELECT status FROM parse_jobs WHERE id=?',(job_id,)).fetchone()
            return bool(r and r[0]=='cancelled')
    with fitz.open(path) as pdf:
        total=len(pdf)
        indices = [page_number-1] if scope=='page' else list(range(total))
        if not 1<=page_number<=total: raise ValueError('页码不存在')
        # Prioritize current page, then adjacent pages, then remaining pages.
        if scope!='page': indices.sort(key=lambda x:abs(x-(page_number-1)))
        for done,i in enumerate(indices):
            if job_id:
                with s.db() as conn:
                    job=conn.execute('SELECT status FROM parse_jobs WHERE id=?',(job_id,)).fetchone()
                    if job and job['status']=='cancelled': return {'id':doc_id,'cancelled':True}
            r=None
            if resume:
                with s.db() as conn:cached=conn.execute('SELECT payload FROM page_revisions WHERE document_id=? AND page_number=? AND revision=?',(doc_id,i+1,revision)).fetchone()
                if cached:
                    payload=json.loads(cached[0])
                    if payload.pop('pipeline_version',None)==pipeline.VERSION and not payload.get('error_code'):r=payload
            if r is None:
                try:r=pipeline.parse_page(pdf[i],info,force,cancelled)
                except pipeline.ParseCancelled:return {'id':doc_id,'cancelled':True}
            r['page_number']=i+1; r['revision']=revision
            results.append(r)
            with s.db() as conn:
                conn.execute('INSERT OR REPLACE INTO page_revisions VALUES(?,?,?,?)',(doc_id,i+1,revision,json.dumps(dict(r,pipeline_version=pipeline.VERSION),ensure_ascii=False)))
                failed=sum(bool(p['error_code']) for p in results)
                conn.execute("UPDATE parse_jobs SET completed_pages=?,failed_pages=?,total_pages=?,stage=?,error_json=? WHERE id=?",
                    (done+1,failed,len(indices),'OCR / quality',json.dumps([{'page':p['page_number'],'code':p['error_code']} for p in results if p['error_code']]),job_id))
                conn.execute('UPDATE import_jobs SET progress=?,message=? WHERE id=?',(round((done+1)/len(indices)*95),f'已分析 {done+1}/{len(indices)} 页；失败 {failed}',job_id))
    # Preserve old blocks and pages in the immutable revision archive.
    if cancelled():return {'id':doc_id,'cancelled':True}
    from collections import Counter
    header_counts=Counter(' '.join(b['text'].split()) for r in results if not r['error_code'] for b in r['blocks'] if b['bbox'][3]<r['page_height']*.14)
    if scope=='page':
        with s.db() as conn:
            for row in conn.execute("SELECT b.text FROM text_blocks b JOIN pages p ON p.id=b.page_id WHERE p.document_id=? AND b.block_type='header'",(doc_id,)):
                header_counts[' '.join(row[0].split())]+=3
    for r in results:
        if r['error_code']:
            continue
        for b in r['blocks']:
            if b['bbox'][3]<r['page_height']*.14 and header_counts[' '.join(b['text'].split())]>=3:b['kind']='header'
        r['effective_text']='\n'.join(b['text'] for b in r['blocks'] if b['kind'] not in ('header','footer')) if r['page_kind']!='non_body' else ''
    with s.db() as conn:
        if old:
            for row in conn.execute('SELECT * FROM pages WHERE document_id=?',(doc_id,)).fetchall():
                archived=dict(row)
                archived['blocks']=[dict(b) for b in conn.execute('SELECT * FROM text_blocks WHERE page_id=?',(row['id'],))]
                conn.execute('INSERT OR IGNORE INTO page_revisions VALUES(?,?,?,?)',(doc_id,row['page_number'],old['parse_revision'],json.dumps(archived)))
        else:
            conn.execute('INSERT INTO documents(id,file_path,file_name,file_hash,file_size,page_count,language,parse_status,ocr_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                (doc_id,str(path),name,digest,size,total,'en','parsing','pending',s.NOW(),s.NOW()))
        for r in results:
            conn.execute('INSERT OR REPLACE INTO page_revisions VALUES(?,?,?,?)',(doc_id,r['page_number'],revision,json.dumps(dict(r,pipeline_version=pipeline.VERSION),ensure_ascii=False)))
            if r['error_code'] and old:
                conn.execute('UPDATE pages SET error_code=?,error_message=?,quality_reason=?,ocr_status=? WHERE document_id=? AND page_number=?',
                    (r['error_code'],r['error_message'],'reparse_failed_previous_revision_retained',r['ocr_status'],doc_id,r['page_number']))
                continue
            fields=[k for k in r if k!='blocks']
            fields+=['document_id']; values=[r[k] for k in fields[:-1]]+[doc_id]
            updates=','.join(f'{k}=excluded.{k}' for k in fields if k not in ('document_id','page_number'))
            conn.execute(f"INSERT INTO pages({','.join(fields)}) VALUES({','.join('?' for _ in fields)}) ON CONFLICT(document_id,page_number) DO UPDATE SET {updates}",values)
            pid=conn.execute('SELECT id FROM pages WHERE document_id=? AND page_number=?',(doc_id,r['page_number'])).fetchone()[0]
            # Old block identity survives in page_revisions; new revision gets new block IDs.
            conn.execute('DELETE FROM text_blocks WHERE page_id=?',(pid,))
            for order,b in enumerate(r['blocks']):
                conn.execute('INSERT INTO text_blocks(page_id,block_index,block_type,text,bbox,confidence,revision,source,reading_order,paragraph_key) VALUES(?,?,?,?,?,?,?,?,?,?)',
                    (pid,order,b['kind'],b['text'],json.dumps(b['bbox']),b['confidence'],revision,b['source'],order,b.get('paragraph','')))
        rows=conn.execute('SELECT effective_text,page_kind,error_code,ocr_status FROM pages WHERE document_id=?',(doc_id,)).fetchall()
        usable=sum(bool(p['effective_text']) and not p['error_code'] for p in rows)
        nonbody=sum(p['page_kind'] in ('blank','non_body') and not p['error_code'] for p in rows)
        failed=total-usable-nonbody
        status='ready' if failed==0 else ('partial' if usable else 'needs_ocr')
        conn.execute('UPDATE documents SET parse_revision=?,pipeline_version=?,quality_status=?,parse_status=?,ocr_status=?,updated_at=? WHERE id=?',
            (revision,pipeline.VERSION,status,status,'completed' if any(p['ocr_status']=='completed' for p in rows) else 'not_needed',s.NOW(),doc_id))
        conn.execute("UPDATE parse_jobs SET status=?,stage='finished',error_json=? WHERE id=?",('completed' if not failed else 'partial',json.dumps({'usable':usable,'non_body':nonbody,'failed':failed}),job_id))
    return dict(id=doc_id,file_name=name,page_count=total,parse_revision=revision,parse_status=status,ocr_status='completed' if info['available'] else 'unavailable',usable_pages=usable,non_body_pages=nonbody,failed_pages=failed)

def run_job(job_id,doc_id,scope,page_number,force,resume=False):
    import server as s
    try:
        with s.db() as conn: doc=conn.execute('SELECT * FROM documents WHERE id=?',(doc_id,)).fetchone()
        return parse_document(Path(doc['file_path']),doc_id,doc['file_name'],doc['file_hash'],doc['file_size'],job_id,scope,page_number,force,resume)
    except Exception as exc:
        with s.db() as conn: conn.execute("UPDATE parse_jobs SET status='failed',stage='error',error_json=? WHERE id=?",(json.dumps({'error':type(exc).__name__,'message':str(exc)[:300]}),job_id))
        raise
