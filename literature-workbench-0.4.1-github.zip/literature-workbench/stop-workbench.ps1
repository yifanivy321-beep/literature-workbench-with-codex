$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidPath = Join-Path $projectRoot '.workbench-data\server.pid'
if (Test-Path -LiteralPath $pidPath) {
  $serverPid = [int](Get-Content -LiteralPath $pidPath -Raw)
  $listener = netstat -ano -p tcp | Select-String '^\s*TCP\s+127\.0\.0\.1:4173\s+.*LISTENING\s+(\d+)\s*$' | ForEach-Object { [int]$_.Matches[0].Groups[1].Value } | Where-Object { $_ -eq $serverPid }
  $proc = Get-Process -Id $serverPid -ErrorAction SilentlyContinue
  if ($listener -and $proc -and $proc.ProcessName -match 'python') { Stop-Process -Id $serverPid -ErrorAction SilentlyContinue }
  Remove-Item -LiteralPath $pidPath -ErrorAction SilentlyContinue
  Write-Output '工作台后台服务已停止。'
} else {
  Write-Output '未找到由启动脚本记录的工作台后台服务。'
}
