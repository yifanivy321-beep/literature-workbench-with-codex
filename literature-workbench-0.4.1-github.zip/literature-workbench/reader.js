import * as pdfjs from '/vendor/pdfjs/package/build/pdf.mjs';
pdfjs.GlobalWorkerOptions.workerSrc='/vendor/pdfjs/package/build/pdf.worker.mjs';
let pdf=null, documentId=null, epoch=0, renderTask=null, viewport=null, current=null, rotation=0;
let continuous=false, slots=[], scrollTimer=null, navigating=false, activeZoom=100, activeFit=true, pendingPage=null;
const host=document.querySelector('#pdfReader');
const canvas=document.createElement('canvas'),layer=document.createElement('div');
layer.className='ocr-text-layer';host.append(canvas,layer);
const askButton=document.createElement('button');askButton.className='paragraph-ask hidden';host.append(askButton);
host.addEventListener('pointerleave',()=>askButton.classList.add('hidden'));
const escape=()=>window.workbenchReader;
async function draw(pageNumber,zoom,fitWidth){
  if(!pdf)return;
  host.querySelectorAll('.image-region').forEach(region=>region.remove());
  activeZoom=zoom;activeFit=fitWidth;pendingPage=pageNumber;
  if(continuous && slots[pageNumber-1]){
    const slot=slots[pageNumber-1];
    if(host.parentElement!==slot){slot.append(host);}
  }
  const stamp=++epoch;
  if(renderTask){renderTask.cancel();try{await renderTask.promise;}catch{}renderTask=null;}
  const page=await pdf.getPage(pageNumber);
  if(stamp!==epoch)return;
  const base=page.getViewport({scale:1,rotation:(page.rotate+rotation)%360});
  const container=document.querySelector('#documentView');
  const scale=fitWidth==='page'?Math.max(.1,Math.min((container.clientWidth-32)/base.width,(container.clientHeight-32)/base.height)):fitWidth?Math.max(.1,(container.clientWidth-32)/base.width):zoom/100;
  viewport=page.getViewport({scale,rotation:(page.rotate+rotation)%360});
  const ratio=Math.min(window.devicePixelRatio||1,2);
  canvas.width=Math.ceil(viewport.width*ratio);canvas.height=Math.ceil(viewport.height*ratio);
  canvas.style.width=viewport.width+'px';canvas.style.height=viewport.height+'px';
  host.style.width=viewport.width+'px';host.style.height=viewport.height+'px';
  if(continuous){for(const slot of slots){slot.style.width=viewport.width+'px';slot.style.height=viewport.height+'px';}}
  if(continuous&&!navigating)slots[pageNumber-1].scrollIntoView({block:'start'});
  layer.style.width=viewport.width+'px';layer.style.height=viewport.height+'px';layer.replaceChildren();askButton.classList.add('hidden');
  renderTask=page.render({canvasContext:canvas.getContext('2d'),viewport,transform:[ratio,0,0,ratio,0,0]});
  try{await renderTask.promise;}catch(e){if(e.name!=='RenderingCancelledException')throw e;return;}
  if(stamp!==epoch)return;renderTask=null;
  const response=await fetch(`/api/documents/${documentId}/pages/${pageNumber}`);
  if(!response.ok)return;
  const pageData=await response.json();
  if(stamp!==epoch)return;
  current=pageData;
  const notesResponse=await fetch(`/api/documents/${documentId}/annotations`);
  const notes=notesResponse.ok?await notesResponse.json():[];
  if(stamp!==epoch)return;
  for(const block of current.blocks||[]){
    if(['header','footer'].includes(block.block_type))continue;
    const bbox=typeof block.bbox==='string'?JSON.parse(block.bbox):block.bbox;
    // Backend bboxes are CropBox-relative top-left coordinates; PDF.js wants PDF bottom-left.
    const view=page.view;
    const pdfRect=[view[0]+bbox[0],view[3]-bbox[3],view[0]+bbox[2],view[3]-bbox[1]];
    const r=viewport.convertToViewportRectangle(pdfRect);
    const top=viewport.convertToViewportPoint(view[0]+bbox[0],view[3]-bbox[1]);
    const axis=viewport.convertToViewportPoint(view[0]+bbox[0]+1,view[3]-bbox[1]);
    const angle=Math.atan2(axis[1]-top[1],axis[0]-top[0])*180/Math.PI;
    const x=top[0],y=top[1],w=(bbox[2]-bbox[0])*scale,h=(bbox[3]-bbox[1])*scale;
    const el=document.createElement('span');el.className='ocr-line';el.textContent=block.text;
    el.dataset.blockId=block.id;el.dataset.page=pageNumber;el.dataset.revision=current.parse_revision;
    const norm=t=>t.replace(/\s+/g,' ').trim();
    if(notes.some(n=>n.page_number===pageNumber&&(norm(n.selected_text).includes(norm(block.text))||norm(block.text).includes(norm(n.selected_text)))))el.classList.add('saved-highlight');
    const fontSize=Math.max(5,h*.85);const measure=canvas.getContext('2d');measure.font=`${fontSize}px serif`;
    const natural=Math.max(1,measure.measureText(block.text).width);
    el.style.cssText=`left:${x}px;top:${y}px;width:${natural}px;height:${h}px;font-family:serif;font-size:${fontSize}px;transform:rotate(${angle}deg) scaleX(${w/natural});`;
    el.title=block.source==='ocr'?'OCR 转录 · 双击询问 / Double-click to ask':'双击询问 / Double-click to ask';
    el.ondblclick=()=>{
      // OCR paragraph identifiers can repeat on disjoint columns/regions.
      // Only join the contiguous run around the clicked block in reading order.
      const body=current.blocks.filter(b=>!['header','footer'].includes(b.block_type));
      let first=body.findIndex(b=>b.id===block.id),last=first;
      if(block.paragraph_key){
        while(first>0&&body[first-1].paragraph_key===block.paragraph_key)first--;
        while(last+1<body.length&&body[last+1].paragraph_key===block.paragraph_key)last++;
      }
      const related=body.slice(first,last+1);
      const text=related.map(b=>b.text).join('\n');
      window.dispatchEvent(new CustomEvent('paper-selection',{detail:{text,page:pageNumber,blockIds:related.map(b=>b.id),revision:current.parse_revision,bbox}}));
    };
    el.onpointerenter=()=>{
      const bounds=el.getBoundingClientRect(),container=host.getBoundingClientRect();
      askButton.textContent=document.documentElement.lang==='en'?'Ask passage':'询问这段';
      askButton.style.left=Math.min(viewport.width-80,Math.max(0,bounds.right-container.left-75))+'px';
      askButton.style.top=Math.max(0,bounds.top-container.top-22)+'px';
      askButton.onclick=el.ondblclick;askButton.classList.remove('hidden');
    };
    layer.append(el);
  }
  window.dispatchEvent(new CustomEvent('reader-page',{detail:{page:pageNumber,zoom:Math.round(scale*100),data:current}}));
  pendingPage=null;
  const target=window.workbenchReader.pendingQuote;
  if(target){
    const needle=target.replace(/\s+/g,' ').trim();
    let first=null;
    for(const el of layer.children)if(el.textContent.replace(/\s+/g,' ').includes(needle)||needle.includes(el.textContent.replace(/\s+/g,' '))){el.classList.add('citation-highlight');first=first||el;}
    first?.scrollIntoView({block:'center',behavior:'smooth'});
    window.workbenchReader.pendingQuote=null;
  }
}
window.workbenchReader={
  ready:true,pendingQuote:null,
  async open(id){
    const openStamp=++epoch;documentId=id;current=null;
    document.querySelector('#documentView').append(host);slots.forEach(s=>s.remove());slots=[];
    if(pdf)await pdf.destroy();
    const loaded=await pdfjs.getDocument({url:`/api/documents/${id}/file`,cMapUrl:'/vendor/pdfjs/package/cmaps/',cMapPacked:true,standardFontDataUrl:'/vendor/pdfjs/package/standard_fonts/'}).promise;
    if(openStamp!==epoch){await loaded.destroy();return;}pdf=loaded;
    rotation=0;
    if(continuous)buildSlots();
    let saved={};try{saved=JSON.parse(localStorage.getItem('reading-position:'+id)||'{}');}catch{}
    await draw(Math.max(1,Math.min(pdf.numPages,saved.page||1)),saved.zoom||100,saved.fit??true);
  },
  draw,
  setContinuous(value){continuous=value;if(!pdf)return;const page=current?.page_number||1;document.querySelector('#documentView').append(host);slots.forEach(s=>s.remove());slots=[];if(continuous)buildSlots();return draw(page,activeZoom,activeFit);},
  async rotate(page,zoom,fit){rotation=(rotation+90)%360;await draw(page,zoom,fit);},
  async imageSelection(){
    host.classList.toggle('select-image');
  }
};
function buildSlots(){
  const container=document.querySelector('#documentView');
  for(let p=1;p<=pdf.numPages;p++){
    const slot=document.createElement('div');slot.className='continuous-page';slot.dataset.page=p;
    slot.style.height=(viewport?.height||850)+'px';slot.style.width=(viewport?.width||600)+'px';
    const image=document.createElement('img');image.alt=`PDF ${p}`;image.loading='lazy';image.dataset.src=`/api/documents/${documentId}/pages/${p}/image?dpi=100`;
    slot.append(image);container.append(slot);slots.push(slot);
  }
}
document.querySelector('#documentView').addEventListener('scroll',()=>{
  if(!continuous||!slots.length)return;
  clearTimeout(scrollTimer);scrollTimer=setTimeout(async()=>{
    const container=document.querySelector('#documentView'),bounds=container.getBoundingClientRect();
    let best=null,distance=Infinity;
    for(const slot of slots){const r=slot.getBoundingClientRect(),image=slot.querySelector('img');
      if(r.bottom>bounds.top-900&&r.top<bounds.bottom+900){if(!image.hasAttribute('src'))image.src=image.dataset.src;}else image.removeAttribute('src');
      const d=Math.abs(r.top-bounds.top);if(d<distance){distance=d;best=slot;}
    }
    if(best&&pendingPage===null&&Number(best.dataset.page)!==current?.page_number){navigating=true;try{await draw(Number(best.dataset.page),activeZoom,activeFit);}catch(e){console.error(e);}finally{navigating=false;}}
  },140);
});
let imageStart=null,overlay=null;
host.addEventListener('pointerdown',e=>{
  if(!host.classList.contains('select-image'))return;
  const r=host.getBoundingClientRect();imageStart=[e.clientX-r.left,e.clientY-r.top];
  overlay=document.createElement('div');overlay.className='image-region';host.append(overlay);host.setPointerCapture(e.pointerId);e.preventDefault();
});
host.addEventListener('pointermove',e=>{
  if(!imageStart)return;
  const r=host.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
  overlay.style.cssText=`left:${Math.min(x,imageStart[0])}px;top:${Math.min(y,imageStart[1])}px;width:${Math.abs(x-imageStart[0])}px;height:${Math.abs(y-imageStart[1])}px`;
});
host.addEventListener('pointerup',e=>{
  if(!imageStart)return;
  const r=host.getBoundingClientRect(),p0=viewport.convertToPdfPoint(...imageStart),p1=viewport.convertToPdfPoint(e.clientX-r.left,e.clientY-r.top);
  const view=pdf?viewport.viewBox:[0,0,0,0];
  const bbox=[Math.min(p0[0],p1[0])-view[0],view[3]-Math.max(p0[1],p1[1]),Math.max(p0[0],p1[0])-view[0],view[3]-Math.min(p0[1],p1[1])];
  imageStart=null;host.classList.remove('select-image');
  if(bbox[2]-bbox[0]>3&&bbox[3]-bbox[1]>3)window.dispatchEvent(new CustomEvent('paper-image-selection',{detail:{bbox,page:current?.page_number}}));
});
document.querySelector('#documentView').addEventListener('wheel',e=>{
  if(continuous)return;
  if(e.ctrlKey)return;
  const container=document.querySelector('#documentView');
  const atEnd=container.scrollTop+container.clientHeight>=container.scrollHeight-2;
  const atStart=container.scrollTop<=1;
  if((e.deltaY>0&&atEnd)||(e.deltaY<0&&atStart)){
    const now=Date.now();if(now-(host.lastFlip||0)<550)return;host.lastFlip=now;
    window.dispatchEvent(new CustomEvent('reader-flip',{detail:{direction:e.deltaY>0?1:-1}}));
  }
},{passive:true});
window.dispatchEvent(new Event('reader-ready'));
