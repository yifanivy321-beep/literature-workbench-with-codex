"""Local reading records and lossless Markdown exports."""
from fastapi import HTTPException
from fastapi.responses import Response
from pydantic import BaseModel, Field


class NoteEdit(BaseModel):
    note: str = Field(max_length=30000)
    color: str = 'amber'


def install_library_routes(app):
    import server as s

    @app.patch('/api/annotations/{annotation_id}')
    def edit_note(annotation_id: str, body: NoteEdit):
        if body.color not in ('amber', 'green', 'blue', 'pink'):
            raise HTTPException(400, '批注颜色无效')
        with s.db() as conn:
            result = conn.execute('UPDATE annotations SET note=?,color=? WHERE id=?',
                                  (body.note, body.color, annotation_id))
            if not result.rowcount:
                raise HTTPException(404, '批注不存在')
            return dict(conn.execute('SELECT * FROM annotations WHERE id=?', (annotation_id,)).fetchone())

    @app.delete('/api/conversations/{conversation_id}/messages')
    def clear_messages(conversation_id: str):
        with s.db() as conn:
            if not conn.execute('SELECT 1 FROM conversations WHERE id=?', (conversation_id,)).fetchone():
                raise HTTPException(404, '会话不存在')
            conn.execute('DELETE FROM messages WHERE conversation_id=?', (conversation_id,))
            conn.execute('UPDATE conversations SET updated_at=? WHERE id=?', (s.NOW(), conversation_id))
        return {'cleared': True}

    @app.get('/api/documents/{doc_id}/notes.md')
    def export_notes(doc_id: str):
        with s.db() as conn:
            doc = conn.execute('SELECT * FROM documents WHERE id=?', (doc_id,)).fetchone()
            if not doc:
                raise HTTPException(404, '文献不存在')
            lines = [f"# {doc['file_name']} · 阅读笔记", '', f"导出时间：{s.NOW()}", '', '## 书签', '']
            for mark in conn.execute('SELECT * FROM bookmarks WHERE document_id=? ORDER BY page_number', (doc_id,)):
                lines.append(f"- PDF 第 {mark['page_number']} 页：{mark['label']}")
            lines.extend(['', '## 批注', ''])
            for note in conn.execute('SELECT * FROM annotations WHERE document_id=? ORDER BY page_number,created_at', (doc_id,)):
                lines.extend([f"### PDF 第 {note['page_number']} 页", '',
                              '\n'.join('> '+line for line in note['selected_text'].splitlines()), '', note['note'], ''])
        return Response('\n'.join(lines), media_type='text/markdown; charset=utf-8',
                        headers={'Content-Disposition': 'attachment; filename=reading-notes.md'})
