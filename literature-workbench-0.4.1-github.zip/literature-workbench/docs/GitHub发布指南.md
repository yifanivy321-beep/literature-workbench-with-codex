# GitHub 发布指南

## 上传什么

运行 `python tools/package_workbench.py` 后，解压 `dist/literature-workbench-0.4.1-github.zip`。**只把解压后的 literature-workbench 目录内容上传到新仓库**，不要上传当前开发目录的全部文件。该目录已按公开文件清单筛选，包含 README、使用/登录文档、截图、必要代码、vendor 许可证和人工演示 PDF。

在 GitHub 创建空仓库，使用 Add file → Upload files 上传目录内容，或在干净的解压目录初始化 Git，通过 GitHub Desktop 提交和推送。将 ZIP 和 `.sha256` 作为 Release 附件，方便使用者下载。不要把 ZIP 本身作为仓库唯一内容，否则 GitHub 首页无法显示 README 与截图。

## 复现打包

```powershell
python tools/package_workbench.py
```

脚本按白名单收集，输出 ZIP、SHA-256 及文件清单。个人数据、历史记录、Codex、Tesseract Windows 二进制、测试缓存、旧 dist 和 output 产物不会自动进入发布包。演示 PDF 使用明确的单文件白名单。

## 发布前验证

在解压目录执行安装，运行启动脚本；打开演示 PDF 检查阅读。单独安装 Tesseract 中英文语言包后，用自己的扫描件检查有效正文。问答由使用者自行登录 CLI 并测试。不要发布 `.workbench-data`、账号令牌、环境日志、个人会话或真实论文副本。

原有项目没有授权声明，本次没有代替著作权人选择许可证。若要作为正式开源项目发布，请先由著作权人决定与 PyMuPDF 等依赖兼容的开源许可；详细说明见 THIRD_PARTY_NOTICES.md。

发布版本是可安装的 Python 源码包，不是无需 Python 的独立桌面安装程序。本次没有创建 GitHub 仓库或上传远端。
