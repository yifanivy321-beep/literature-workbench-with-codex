"""Local image-first, bounded, layout-aware PDF parsing. Coordinates: unrotated PDF space."""
from __future__ import annotations
import csv
import io
import os
import re
import shutil
import subprocess
import time
from pathlib import Path
import fitz
ROOT = Path(__file__).resolve().parent
FLAGS = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
VERSION = 'image-layout-2'

def tess_args(exe):
    data=Path(exe).parent/'tessdata'
    if data.is_dir():
        try:
            location = os.path.relpath(data, ROOT)
        except ValueError:
            # Windows installations can be on a different drive from the project.
            location = str(data)
        return ['--tessdata-dir', location]
    return []

def engine_path():
    configured = os.environ.get('WORKBENCH_TESSERACT')
    candidates = [configured, str(ROOT/'vendor'/'tesseract'/'tesseract.exe'), shutil.which('tesseract'), r'C:\Program Files\Tesseract-OCR\tesseract.exe']
    return next((str(Path(p).resolve()) for p in candidates if p and Path(p).is_file()), None)

def engine_info():
    exe = engine_path()
    if not exe: return dict(tesseract=False, available=False, code='OCR_MISSING', languages=[], formula=False, table=False)
    try:
        v = subprocess.run([exe, '--version'], capture_output=True, encoding='utf-8', errors='replace', timeout=10, creationflags=FLAGS)
        p = subprocess.run([exe, *tess_args(exe), '--list-langs'], cwd=ROOT, capture_output=True, encoding='utf-8', errors='replace', timeout=10, creationflags=FLAGS)
        langs = [x.strip() for x in (p.stdout+p.stderr).splitlines() if re.fullmatch('[a-z_]{3,12}', x.strip())]
        return dict(tesseract=True, available='eng' in langs, executable=exe, version=v.stdout.splitlines()[0], languages=langs,
                    formula=False, table=False, code='' if 'eng' in langs else 'OCR_LANGUAGE_MISSING')
    except Exception as exc: return dict(tesseract=True, available=False, code='OCR_PROBE_FAILED', error=type(exc).__name__, languages=[], formula=False, table=False)

def union_area(rects, bounds):
    rs = [fitz.Rect(r) & bounds for r in rects]
    rs = [r for r in rs if not r.is_empty]
    xs = sorted({x for r in rs for x in (r.x0, r.x1)})
    total = 0
    for left, right in zip(xs, xs[1:]):
        intervals = sorted((r.y0, r.y1) for r in rs if r.x0 < right and r.x1 > left)
        end = -float('inf'); height = 0
        for lo, hi in intervals:
            height += max(0, hi-max(lo, end)); end = max(end, hi)
        total += (right-left)*height
    return total

def render(page, dpi=300, max_pixels=16000000, clip=None):
    rect = page.rect if clip is None else clip
    scale = min(dpi/72, (max_pixels/max(1,rect.width*rect.height))**0.5)
    return page.get_pixmap(matrix=fitz.Matrix(scale,scale), clip=clip, alpha=False), scale

def footer(text):
    return bool(re.search(r'copy\w{0,3}ght|all rights reserved|downloaded from|jstor|terms.*conditions|management science/vol\.', text, re.I))

def analyze(page):
    native = []
    for b in page.get_text('blocks'):
        if len(b) >= 7 and b[6] == 0 and str(b[4]).strip():
            native.append(dict(text=b[4].strip(), bbox=list(b[:4]), source='native', confidence=1., kind='footer' if footer(b[4]) else 'paragraph'))
    rects = []
    for image in page.get_images(full=True):
        rects.extend(page.get_image_rects(image[0]))
    cov = union_area(rects, page.rect)/max(1,page.rect.get_area())
    body = [b for b in native if b['kind'] != 'footer' and fitz.Rect(b['bbox']).y0 < page.rect.height*.94]
    chars = sum(len(b['text']) for b in body)
    body_area = union_area([b['bbox'] for b in body], page.rect)/max(1,page.rect.get_area())
    scanned = cov > .45 and (chars < 180 or body_area < .01)
    hybrid = cov > .15 and chars >= 180 and body_area < .20
    return dict(native=native, image_coverage=cov, native_body_chars=chars,
                page_kind='scanned' if scanned else ('hybrid' if hybrid else ('native' if body else ('non_body' if native else 'blank'))), needs_ocr=scanned or hybrid)

class ParseCancelled(RuntimeError): pass

def tsv_lines(page, pix, scale, exe, language='eng', psm=3, cancelled=None):
    proc = subprocess.Popen([exe,'stdin','stdout',*tess_args(exe),'-l',language,'--psm',str(psm),'tsv'], cwd=ROOT,
                            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=FLAGS)
    started=time.monotonic(); input_bytes=pix.tobytes('png')
    try:
        while True:
            if cancelled and cancelled():raise ParseCancelled('任务已取消')
            if time.monotonic()-started>150:raise subprocess.TimeoutExpired('tesseract',150)
            try:
                stdout,stderr=proc.communicate(input_bytes,timeout=.25);break
            except subprocess.TimeoutExpired:input_bytes=None
    finally:
        if proc.poll() is None:proc.kill();proc.communicate()
    if proc.returncode: raise RuntimeError('OCR_PROCESS_FAILED')
    groups = {}
    for r in csv.DictReader(io.StringIO(stdout.decode('utf-8','replace')),delimiter='\t'):
        text = (r.get('text') or '').strip()
        if not text or r.get('level') != '5': continue
        x,y,w,h = [float(r[k])/scale for k in ('left','top','width','height')]
        rect = fitz.Rect(x,y,x+w,y+h) * page.derotation_matrix
        key = tuple(r[k] for k in ('block_num','par_num','line_num'))
        groups.setdefault(key, []).append((text, list(rect), max(0,float(r['conf']))/100))
    lines = []
    for key, words in groups.items():
        r = fitz.Rect(words[0][1])
        for _,box,_ in words[1:]: r |= fitz.Rect(box)
        text = ' '.join(w[0] for w in words)
        lines.append(dict(text=text, bbox=list(r), confidence=sum(w[2] for w in words)/len(words), source='ocr', kind='line', paragraph=f'{key[0]}:{key[1]}'))
    return lines

def reading_order(lines, width):
    # Auto-layout finds full-width headings/abstract first; order within each region
    # is top-to-bottom, with complete left column before right column.
    mid = width/2
    bottom = max((b['bbox'][3] for b in lines), default=1)
    spans = [b for b in lines if (b['bbox'][0] < mid*.65 and b['bbox'][2] > mid*1.35)
             or (b['bbox'][0] < mid < b['bbox'][2] and b['bbox'][3] < bottom*.12)
             or footer(b['text'])]
    cuts = sorted({round(b['bbox'][3],1) for b in spans})
    groups = []
    remaining = list(lines)
    for cut in cuts + [float('inf')]:
        region = [b for b in remaining if (b['bbox'][1]+b['bbox'][3])/2 <= cut]
        remaining = [b for b in remaining if b not in region]
        full = [b for b in region if b in spans]
        cols = [b for b in region if b not in spans]
        groups.extend(sorted(cols,key=lambda b:(0 if (b['bbox'][0]+b['bbox'][2])/2 < mid else 1,b['bbox'][1])))
        groups.extend(sorted(full,key=lambda b:b['bbox'][1]))
    return groups

def merge_regions(native, ocr):
    merged=list(ocr)
    for line in native:
        box=fitz.Rect(line['bbox']);norm=' '.join(line['text'].split())
        merged=[b for b in merged if not (b['source']=='ocr' and (fitz.Rect(b['bbox'])&box).get_area()/max(1,fitz.Rect(b['bbox']).get_area())>.55)]
        if norm not in [' '.join(b['text'].split()) for b in merged]:merged.append(line)
    return merged

def parse_page(page, info, force=False, cancelled=None):
    analysis = analyze(page)
    pix, scale = render(page)  # Render even for native pages; image-first audit.
    result = dict(raw_text=page.get_text('text',sort=True).strip(), ocr_text='', effective_text='', blocks=[],
                  page_width=page.cropbox.width, page_height=page.cropbox.height, rotation=page.rotation,
                  image_coverage=analysis['image_coverage'], native_body_chars=analysis['native_body_chars'],
                  page_kind=analysis['page_kind'], text_source='native', parse_confidence=1., ocr_status='not_needed',
                  engine='', engine_version='', quality_reason='', error_code='', error_message='', page_label='')
    blocks = []
    for block_no,block in enumerate(page.get_text('dict')['blocks']):
        for line in block.get('lines',[]):
            text=''.join(span['text'] for span in line['spans']).strip()
            if text:blocks.append(dict(text=text,bbox=list(line['bbox']),source='native',confidence=1.,kind='footer' if footer(text) else 'line',paragraph=str(block_no)))
    native_lines=list(blocks)
    if analysis['needs_ocr'] or force:
        if not info['available']:
            result.update(ocr_status='unavailable', error_code=info['code'], error_message='本地 OCR 引擎或 eng 语言包不可用', text_source='unavailable', parse_confidence=0.)
            blocks = []
        else:
            try:
                langs = os.environ.get('WORKBENCH_OCR_LANGS') or ('eng+chi_sim' if 'chi_sim' in info['languages'] else 'eng')
                lines = tsv_lines(page,pix,scale,info['executable'],langs,cancelled=cancelled)
                blocks = reading_order(lines,page.cropbox.width)
                if not blocks: raise RuntimeError('OCR_EMPTY')
                result['ocr_text'] = '\n'.join(b['text'] for b in blocks)
                result.update(text_source='ocr',ocr_status='completed',engine='Tesseract',engine_version=info['version'],parse_confidence=sum(b['confidence'] for b in blocks)/len(blocks))
                if analysis['page_kind'] == 'hybrid':
                    blocks=merge_regions(native_lines,blocks)
                    blocks = reading_order(blocks,page.cropbox.width)
                    result['text_source'] = 'hybrid'
                if len(result['ocr_text']) < 120 and all(footer(b['text']) or len(b['text'])<60 for b in blocks): result['page_kind']='non_body'
            except ParseCancelled:raise
            except subprocess.TimeoutExpired:
                result.update(ocr_status='failed',error_code='OCR_TIMEOUT',error_message='单页 OCR 超时，可局部重试',text_source='unavailable',parse_confidence=0.); blocks=[]
            except Exception as exc:
                result.update(ocr_status='failed',error_code=str(exc),error_message='OCR 识别失败，可局部重试',text_source='unavailable',parse_confidence=0.); blocks=[]
    for i,b in enumerate(blocks):
        b['reading_order']=i
        if footer(b['text']): b['kind']='footer'
        if b['bbox'][1] > page.cropbox.height*.90 and re.search(r'0025-1909|\$\d',b['text']): b['kind']='footer'
        if b['bbox'][1] > page.cropbox.height*.85 and re.fullmatch(r'\d{1,5}',b['text'].strip()):b['kind']='footer'
        if b['kind']!='footer' and len(re.findall(r'[=∫Σλπ≤≥]|\b\w\([^)]*\)', b['text']))>=2:
            b['kind']='formula_candidate'
        if b['kind']!='footer' and len(re.findall(r'\b\d+(?:\.\d+)?\b',b['text']))>=5 and len(re.findall(r'[A-Za-z]{3,}',b['text']))<3:
            b['kind']='table_candidate'
    body = [b for b in blocks if b['kind'] not in ('header','footer')]
    result['blocks']=blocks
    result['effective_text']='\n'.join(b['text'] for b in body)
    if result['ocr_status']=='completed' and result['parse_confidence']<.65:
        result['quality_reason']='low_quality: OCR 内部置信分低；不代表实测正确率'
    if result['page_kind']=='non_body': result['effective_text']=''
    result['quality_reason'] = result['quality_reason'] or result['error_message'] or ('non_body' if result['page_kind']=='non_body' else 'usable' if result['effective_text'] else 'blank')
    isolated = [b['text'].strip() for b in blocks if re.fullmatch(r'\d{3,5}',b['text'].strip()) and b['bbox'][1]>page.cropbox.height*.85]
    labels = [re.search(r'(\d{3,5})\s*$',b['text']) for b in blocks if 'management science' in b['text'].lower() and b['bbox'][1]>page.cropbox.height*.85]
    labels = [m.group(1) for m in labels if m and m.group(1) not in ('1994','2001')]
    if isolated or labels: result['page_label']=(isolated or labels)[-1]
    if any(b['kind'] in ('formula_candidate','table_candidate') for b in blocks):
        result['quality_reason'] += '; formula/table transcription unverified; inspect image'
    return result
