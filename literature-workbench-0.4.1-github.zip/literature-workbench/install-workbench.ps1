param([switch]$NoShortcut)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$python = (Get-Command python -ErrorAction Stop).Source
$venvPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $venvPython)) {
  & $python -m venv (Join-Path $projectRoot '.venv')
  if ($LASTEXITCODE -ne 0) { throw 'Python 环境创建失败。请安装 Python 3.11 或更新版本。' }
}
& $venvPython -m pip install -r (Join-Path $projectRoot 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw '依赖安装失败，请检查网络后重新运行安装脚本。原数据未修改。' }
& $venvPython (Join-Path $projectRoot 'tools\check_environment.py')
if ($LASTEXITCODE -ne 0) { Write-Warning '部分本地资源未就绪，详见上面的环境检查。' }
if (-not $NoShortcut) {
  $desktop = [Environment]::GetFolderPath('Desktop')
  $shortcut = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $desktop '文献阅读工作台.lnk'))
  $shortcut.TargetPath = 'powershell.exe'
  $shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $projectRoot 'start-workbench.ps1') + '"'
  $shortcut.WorkingDirectory = $projectRoot
  $shortcut.Description = '本地文献阅读、OCR、阅读笔记与 Codex 问答'
  $shortcut.Save()
}
Write-Output '安装完成。双击桌面快捷方式，或运行 start-workbench.ps1。'
