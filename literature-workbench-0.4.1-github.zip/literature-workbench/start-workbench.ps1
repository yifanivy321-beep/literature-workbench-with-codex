﻿param([switch]$NoBrowser)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataRoot = Join-Path $projectRoot '.workbench-data'
$logRoot = Join-Path $dataRoot 'logs'
$pidPath = Join-Path $dataRoot 'server.pid'
$url = 'http://127.0.0.1:4173/'
New-Item -ItemType Directory -Force -Path $logRoot | Out-Null

$health = try { Invoke-RestMethod -Uri 'http://127.0.0.1:4173/api/health' -TimeoutSec 2 } catch { $null }
if (-not $health) {
  $projectPython = Join-Path $projectRoot '.venv\Scripts\python.exe'
  $python = if (Test-Path -LiteralPath $projectPython) { $projectPython } else { (Get-Command python -ErrorAction Stop).Source }
  & $python (Join-Path $projectRoot 'tools\check_environment.py') | Out-File -LiteralPath (Join-Path $logRoot 'environment.json') -Encoding utf8
  if ($LASTEXITCODE -ne 0) { Write-Warning '环境检查发现 OCR 或本地资源缺失；详见 logs/environment.json。原 PDF 阅读仍可尝试启动。' }
  $stdout = Join-Path $logRoot 'server.out.log'
  $stderr = Join-Path $logRoot 'server.err.log'
  $proc = Start-Process -FilePath $python -ArgumentList @('-m','uvicorn','server:app','--host','127.0.0.1','--port','4173') -WorkingDirectory $projectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
  Set-Content -LiteralPath $pidPath -Value $proc.Id -Encoding ascii
  $ready = $false
  for ($i = 0; $i -lt 40; $i++) {
    Start-Sleep -Milliseconds 500
    try { $health = Invoke-RestMethod -Uri 'http://127.0.0.1:4173/api/health' -TimeoutSec 2; $ready = $true; break } catch {}
    if ($proc.HasExited) { break }
  }
  if (-not $ready) {
    if (-not $proc.HasExited) { Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue }
    throw "工作台服务启动失败。查看日志：$stderr"
  }
}

$edgeCandidates = @(
  (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe')
)
$edge = $edgeCandidates | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
if (-not $NoBrowser) {
  if ($edge) { Start-Process -FilePath $edge -ArgumentList @("--app=$url") }
  else { Start-Process $url }
}
Write-Output "文献阅读工作台已启动：$url"
Write-Output "数据目录：$dataRoot"
