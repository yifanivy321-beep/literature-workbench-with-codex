"""Run only after stopping workbench; creates a safety snapshot before restore."""
import argparse,sqlite3,time
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('backup');args=parser.parse_args()
root=Path(__file__).resolve().parents[1];source=Path(args.backup).resolve();target=root/'.workbench-data/workbench.sqlite3'
if not source.is_file():raise SystemExit('Backup not found')
if (root/'.workbench-data/server.pid').exists():raise SystemExit('Stop the managed service first (stop-workbench.ps1)')
with sqlite3.connect(source) as check:
    if check.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise SystemExit('Backup integrity failed')
with sqlite3.connect(target) as current,sqlite3.connect(target.parent/'backups'/f'before-restore-{time.time_ns()}.sqlite3') as safety:current.backup(safety)
with sqlite3.connect(source) as old,sqlite3.connect(target) as current:old.backup(current)
print('Database restored; previous live database retained in backups. Match source snapshot version before restarting.')
