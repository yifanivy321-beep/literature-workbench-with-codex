import sys,json,platform,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from codex_adapter import create_adapter
from pdf_pipeline import engine_info
root=Path(__file__).resolve().parents[1]
assets=['vendor/pdfjs/package/build/pdf.mjs','vendor/pdfjs/package/build/pdf.worker.mjs','vendor/marked/package/lib/marked.umd.js','vendor/dompurify/package/dist/purify.min.js','vendor/katex/package/dist/katex.min.js']
result=dict(python=platform.python_version(),codex=create_adapter().probe(),ocr=engine_info(),assets={p:(root/p).is_file() for p in assets})
print(json.dumps(result,ensure_ascii=False,indent=2))
if not all(result['assets'].values()) or not result['ocr']['available']:sys.exit(1)
