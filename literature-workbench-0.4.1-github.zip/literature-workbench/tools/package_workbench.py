"""Build a public allowlist, without private data or local diagnostics."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FILES = '''.gitignore README.md THIRD_PARTY_NOTICES.md requirements.txt requirements-dev.txt
server.py pdf_pipeline.py parsing_store.py library_api.py workbench_api.py
codex_adapter.py codex_rpc.py index.html styles.css app.js reader.js workspace.js
install-workbench.ps1 start-workbench.ps1 stop-workbench.ps1
tools/check_environment.py tools/restore_database.py tools/package_workbench.py
tests/test_workbench.py tests/test_completion.py
docs/安装与使用.md docs/登录Codex.md docs/GitHub发布指南.md docs/发布验证.md
docs/screenshots/01-reader.jpg docs/screenshots/02-settings.jpg docs/screenshots/03-selection.jpg
output/pdf/reading-workbench-demo.pdf'''.split()
VENDOR_FILES = '''vendor/pdfjs/package/LICENSE
vendor/pdfjs/package/build/pdf.mjs vendor/pdfjs/package/build/pdf.worker.mjs
vendor/katex/package/LICENSE vendor/katex/package/dist/katex.min.js
vendor/katex/package/dist/katex.min.css vendor/katex/package/dist/contrib/auto-render.min.js
vendor/marked/package/LICENSE.md vendor/marked/package/lib/marked.umd.js
vendor/dompurify/package/LICENSE vendor/dompurify/package/dist/purify.min.js'''.split()
VENDOR_DIRS = ['vendor/pdfjs/package/cmaps', 'vendor/pdfjs/package/standard_fonts',
               'vendor/katex/package/dist/fonts']

def sources():
    result = [ROOT / name for name in FILES + VENDOR_FILES]
    for name in VENDOR_DIRS:
        folder = ROOT / name
        if not folder.is_dir():
            raise FileNotFoundError(name)
        result.extend(p for p in folder.rglob('*') if p.is_file())
    for path in result:
        if not path.is_file():
            raise FileNotFoundError(path)
        if path.is_symlink() or not path.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError(f'Unsafe source: {path}')
    return sorted(set(result))

def main():
    paths = sources()
    output = ROOT / 'dist'
    output.mkdir(exist_ok=True)
    target = output / 'literature-workbench-0.4.1-github.zip'
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for path in paths:
            bundle.write(path, 'literature-workbench/' + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as bundle:
        if bundle.testzip() is not None:
            raise RuntimeError('ZIP integrity failed')
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    target.with_suffix('.sha256').write_text(digest + '  ' + target.name + '\n', encoding='ascii')
    manifest = [{'path': p.relative_to(ROOT).as_posix(), 'bytes': p.stat().st_size,
                 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
    target.with_suffix('.manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'{target}\n{len(paths)} files; {target.stat().st_size} bytes\nSHA256 {digest}')

if __name__ == '__main__':
    main()
