"""Native Windows Codex invocation; prompts use stdin."""
from __future__ import annotations
import asyncio
import os
import shutil
import subprocess
import time
import json
from pathlib import Path
FLAGS = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

async def terminate_managed(proc):
    if proc.returncode is not None:return
    if os.name=='nt':
        p=await asyncio.create_subprocess_exec('taskkill','/PID',str(proc.pid),'/T','/F',stdout=asyncio.subprocess.DEVNULL,stderr=asyncio.subprocess.DEVNULL,creationflags=FLAGS)
        try:await asyncio.wait_for(p.wait(),3)
        except asyncio.TimeoutError:p.kill();await p.wait()
    else:proc.terminate()
    try:await asyncio.wait_for(proc.wait(),3)
    except asyncio.TimeoutError:
        if proc.returncode is None:proc.kill()
        await proc.wait()

def classify_error(message: str) -> str:
    s = message.lower()
    if any(x in s for x in ('model not', 'model_unavailable', 'unsupported model', 'does not exist', 'invalid model')): return 'MODEL_UNAVAILABLE'
    if any(x in s for x in ('expired', '401', 'unauthorized')): return 'AUTH_EXPIRED'
    if any(x in s for x in ('not logged', 'login required', 'authentication required')): return 'AUTH_REQUIRED'
    if any(x in s for x in ('quota', 'rate limit', '429', 'usage limit')): return 'QUOTA_EXCEEDED'
    return 'TRANSPORT_FAILED'

class UnsupportedAdapter:
    name = 'unsupported'
    def probe(self):
        return dict(available=False, logged_in=False, executable=None, version=None, adapter=self.name,
                    state='CLI_MISSING', reason='未找到原生 Codex 可执行文件', checked_at=time.time())
class CodexDesktopAdapter(UnsupportedAdapter):
    name = 'desktop-unsupported'
class CodexCliAdapter:
    name = 'cli'
    def __init__(self, executable): self.executable = executable
    @classmethod
    def discover(cls, configured=None):
        candidates = [Path(configured)] if configured else []
        native = shutil.which('codex.exe')
        if native: candidates.append(Path(native))
        wrapper = shutil.which('codex.cmd')
        if wrapper:
            base = Path(wrapper).parent / 'node_modules' / '@openai'
            candidates.extend(base.glob('codex/node_modules/@openai/codex-*/vendor/*/codex/codex.exe'))
            candidates.extend(base.glob('codex/vendor/*/codex/codex.exe'))
        if os.name != 'nt':
            p = shutil.which('codex')
            if p: candidates.append(Path(p))
        for p in candidates:
            if p.is_file() and (os.name != 'nt' or p.suffix.lower() == '.exe'): return cls(str(p.resolve()))
        return None
    def probe(self):
        base = dict(executable=self.executable, adapter=self.name, checked_at=time.time(), protocol_verified=False)
        try:
            v = subprocess.run([self.executable, '--version'], capture_output=True, encoding='utf-8', errors='replace', timeout=8, creationflags=FLAGS)
            a = subprocess.run([self.executable, 'login', 'status'], capture_output=True, encoding='utf-8', errors='replace', timeout=12, creationflags=FLAGS)
            state = 'AUTHENTICATED' if a.returncode == 0 else classify_error(a.stdout+a.stderr)
            return dict(base, available=v.returncode == 0, logged_in=a.returncode == 0, version=v.stdout.strip(), state=state,
                        reason='已登录；协议与所选模型需单独验证' if a.returncode == 0 else ('CLI 未登录，请在终端运行 codex login' if state == 'AUTH_REQUIRED' else '认证检查失败，请重新检查环境'))
        except Exception as exc:
            return dict(base, available=False, logged_in=False, version=None, state='TRANSPORT_FAILED', reason=f'CLI 探测失败：{type(exc).__name__}')
    def command(self, schema_path, workdir, model=None, effort=None, image=None, last_message=None):
        cmd = [self.executable, '-a', 'never', 'exec', '--ephemeral', '--json', '--sandbox', 'read-only',
               '--skip-git-repo-check', '--output-schema', str(schema_path), '-C', workdir]
        if model: cmd += ['--model', model]
        if effort:cmd += ['-c',f'model_reasoning_effort="{effort}"']
        if image:cmd += ['--image',image]
        if last_message:cmd += ['--output-last-message',str(last_message)]
        return cmd + ['-']
    async def start(self, schema_path, workdir, model=None, effort=None, image=None, last_message=None):
        return await asyncio.create_subprocess_exec(*self.command(schema_path, workdir, model,effort,image,last_message), stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, creationflags=FLAGS, limit=4*1024*1024)
    async def generate(self,prompt,schema,cwd,model=None,effort=None,image=None):
        schema_path=Path(cwd)/'answer-schema.json';schema_path.write_text(json.dumps(schema),encoding='utf-8')
        final_path=Path(cwd)/'final-answer.json';proc=await self.start(schema_path,cwd,model,effort,image,final_path)
        tail='';final=''
        async def drain():
            nonlocal tail
            while chunk:=await proc.stderr.read(8192):tail=(tail+chunk.decode('utf-8','replace'))[-3000:]
        stderr=asyncio.create_task(drain())
        try:
            proc.stdin.write(prompt.encode('utf-8'));await proc.stdin.drain();proc.stdin.close()
            yield dict(type='status',actual_model=None,adapter='exec',stream_mode='completion_only')
            async with asyncio.timeout(600):
                while line:=await proc.stdout.readline():
                    try:event=json.loads(line)
                    except ValueError:continue
                    item=event.get('item',{})
                    if event.get('type')=='item.completed' and item.get('type')=='agent_message':final=item.get('text','')
                    if event.get('type') in ('error','turn.failed'):raise RuntimeError(str(event.get('error',{}).get('message',event.get('message','Codex request failed'))))
                code=await proc.wait();await stderr
            if code:raise RuntimeError(classify_error(tail)+': Codex exec request failed; check environment')
            if final_path.exists():final=final_path.read_text(encoding='utf-8')
            if not final:raise RuntimeError('Codex exec returned no final answer')
            yield dict(type='final',text=final)
        finally:
            await terminate_managed(proc);stderr.cancel()
            try:await stderr
            except asyncio.CancelledError:pass
def create_adapter(configured=None): return CodexCliAdapter.discover(configured) or UnsupportedAdapter()
