"""Managed app-server JSONL RPC; no desktop token access."""
from __future__ import annotations
import asyncio
import json
import os
from codex_adapter import FLAGS, terminate_managed
class RpcError(RuntimeError): pass
class CodexRpc:
    def __init__(self, executable):
        self.executable = executable
        self.seq = 0
        self.pending = {}
        self.events = asyncio.Queue(maxsize=4096)
        self.proc = self.reader = self.stderr = None
    async def __aenter__(self):
        try:
            self.proc = await asyncio.create_subprocess_exec(self.executable, 'app-server', '--listen', 'stdio://',
                stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                creationflags=FLAGS, limit=4*1024*1024)
            self.reader = asyncio.create_task(self._read())
            self.stderr = asyncio.create_task(self._drain_stderr())
            await self.call('initialize', {'clientInfo': {'name': 'local_literature_workbench', 'version': '0.3.0'}})
            await self.send({'method': 'initialized', 'params': {}})
            return self
        except BaseException:
            await self.close(); raise
    async def _drain_stderr(self):
        while await self.proc.stderr.read(8192): pass
    async def _read(self):
        failure = None
        try:
            while line := await self.proc.stdout.readline():
                try: event = json.loads(line)
                except ValueError: raise RpcError('Codex 协议返回非 JSON 消息')
                if 'id' in event and ('result' in event or 'error' in event):
                    fut = self.pending.pop(event['id'], None)
                    if fut and not fut.done():
                        if 'error' in event: fut.set_exception(RpcError(str(event['error'].get('message', 'RPC failed'))[:500]))
                        else: fut.set_result(event['result'])
                elif 'id' in event and 'method' in event:
                    await self.send({'id': event['id'], 'error': {'code': -32601, 'message': 'Workbench does not execute tools or approve actions'}})
                elif 'method' in event: await self.events.put(event)
            failure = RpcError('Codex 协议连接已关闭')
        except asyncio.CancelledError: return
        except Exception as exc: failure = exc
        finally:
            if failure:
                for fut in self.pending.values():
                    if not fut.done(): fut.set_exception(failure)
                self.pending.clear()
                await self.events.put({'method': 'transport/error', 'params': {'message': str(failure)}})
    async def send(self, payload):
        self.proc.stdin.write((json.dumps(payload, ensure_ascii=False)+'\n').encode('utf-8'))
        await self.proc.stdin.drain()
    async def call(self, method, params, timeout=30):
        self.seq += 1
        ident = self.seq
        fut = asyncio.get_running_loop().create_future()
        self.pending[ident] = fut
        try:
            await self.send({'id': ident, 'method': method, 'params': params})
            try:
                return await asyncio.wait_for(fut, timeout)
            except asyncio.TimeoutError as exc:
                raise RpcError(f'RPC_TIMEOUT: {method} 在 {timeout} 秒内未响应；请检查所用 CLI 版本、配置和网络，或显式改用 exec 完整答案模式') from exc
        finally: self.pending.pop(ident, None)
    async def models(self):
        models, cursor, seen = [], None, set()
        for _ in range(100):
            response = await self.call('model/list', {'cursor': cursor, 'limit': 100})
            models.extend(response['data'])
            cursor = response.get('nextCursor')
            if not cursor: return models
            if cursor in seen: raise RpcError('模型分页游标重复')
            seen.add(cursor)
        raise RpcError('模型目录超过分页上限')
    async def generate(self, prompt, schema, cwd, model=None, effort=None, image=None):
        info = await self.call('thread/start', {'cwd': cwd, 'ephemeral': True, 'approvalPolicy': 'never',
                              'sandbox': 'read-only', 'model': model, 'developerInstructions': 'Do not invoke tools. Answer only from supplied context.'})
        thread = info['thread']['id']
        yield {'type': 'status', 'actual_model': info.get('model'), 'thread_id': thread, 'adapter': 'app-server'}
        inp = [{'type': 'text', 'text': prompt}]
        if image: inp.append({'type': 'localImage', 'path': image})
        ti = await self.call('turn/start', {'threadId': thread, 'input': inp, 'model': model, 'effort': effort, 'outputSchema': schema})
        turn = ti['turn']['id']
        items, final_items = {}, {}
        try:
            async with asyncio.timeout(600):
                while True:
                    event = await self.events.get()
                    method, p = event['method'], event.get('params', {})
                    if method == 'transport/error': raise RpcError(p['message'])
                    if p.get('threadId') != thread: continue
                    if p.get('turnId') and p['turnId'] != turn: continue
                    if method == 'item/agentMessage/delta':
                        item = p['itemId']; items[item] = items.get(item, '') + p['delta']
                        yield {'type': 'delta', 'item_id': item, 'raw': items[item]}
                    elif method == 'item/completed' and p.get('item', {}).get('type') == 'agentMessage':
                        item = p['item']; final_items[item['id']] = item.get('text', '')
                    elif method == 'turn/completed' and p['turn']['id'] == turn:
                        if p['turn']['status'] != 'completed': raise RpcError('Codex turn '+p['turn']['status']+': '+str(p['turn'].get('error') or ''))
                        values = list(final_items.values()) or list(items.values())
                        if not values: raise RpcError('Codex 未返回答案')
                        yield {'type': 'final', 'text': values[-1]}; return
                    elif method == 'error' and not p.get('willRetry', False):
                        raise RpcError(str(p.get('error', {}).get('message', 'Codex 请求失败'))[:500])
        finally:
            if self.proc and self.proc.returncode is None:
                try: await self.call('turn/interrupt', {'threadId': thread, 'turnId': turn}, timeout=2)
                except Exception: pass
    async def close(self):
        if self.proc and self.proc.returncode is None:
            await terminate_managed(self.proc)
        for task in (self.reader, self.stderr):
            if task:
                task.cancel()
                try: await task
                except asyncio.CancelledError: pass
        for fut in self.pending.values():
            if not fut.done(): fut.cancel()
        self.pending.clear()
    async def __aexit__(self, *args): await self.close()
