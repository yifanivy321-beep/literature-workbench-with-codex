"""Regression coverage for reading records and large-document local access."""
from test_workbench import WorkbenchTests
import unittest


class CompletionTests(unittest.TestCase):
    setUp = WorkbenchTests.setUp
    tearDown = WorkbenchTests.tearDown

    def test_rpc_timeout_identifies_stage_and_cleans_pending(self):
        import asyncio
        from unittest.mock import AsyncMock
        from codex_rpc import CodexRpc, RpcError
        async def check():
            rpc=CodexRpc('unused')
            rpc.send=AsyncMock()
            with self.assertRaisesRegex(RpcError,'RPC_TIMEOUT: initialize'):
                await rpc.call('initialize',{},timeout=.01)
            self.assertEqual(rpc.pending,{})
        asyncio.run(check())
    def test_note_edit_export_and_delete(self):
        note = self.client.post('/api/annotations', json={'document_id':'doc','page_number':1,'selected_text':'Evidence','note':'initial'}).json()
        path = '/api/annotations/'+note['id']
        self.assertEqual(self.client.patch(path,json={'note':'修订笔记','color':'blue'}).status_code,200)
        export = self.client.get('/api/documents/doc/notes.md')
        self.assertIn('修订笔记',export.text)
        self.assertIn('> Evidence',export.text)
        self.assertEqual(self.client.patch(path,json={'note':'x','color':'invalid'}).status_code,400)
        self.assertEqual(self.client.delete(path).status_code,200)
        self.assertEqual(self.client.get('/api/documents/doc/annotations').json(),[])

    def test_clear_preserves_conversation_removes_citations(self):
        import server as s
        with s.db() as conn:
            conn.execute('INSERT INTO messages(id,conversation_id,role,content,created_at) VALUES(?,?,?,?,?)',('m',self.conv,'assistant','reply',s.NOW()))
            conn.execute('INSERT INTO citations(message_id,document_id,page_number,quote,confidence) VALUES(?,?,?,?,?)',('m','doc',1,'Evidence',.9))
        self.assertEqual(self.client.delete(f'/api/conversations/{self.conv}/messages').status_code,200)
        self.assertEqual(self.client.get(f'/api/conversations/{self.conv}/messages').json(),[])
        with s.db() as conn:
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM citations').fetchone()[0],0)
            self.assertEqual(conn.execute('SELECT COUNT(*) FROM conversations').fetchone()[0],1)

    def test_literal_search_and_hit_context(self):
        import server as s
        with s.db() as conn:conn.execute('UPDATE pages SET effective_text=?',('a '*1000+'target 50% _ exact',))
        hits=self.client.get('/api/search',params={'document_id':'doc','q':'target'}).json()
        self.assertIn('target',hits[0]['snippet'])
        self.assertEqual(len(self.client.get('/api/search',params={'document_id':'doc','q':'%'}).json()),1)
        self.assertEqual(self.client.get('/api/search',params={'document_id':'doc','q':'%%'}).json(),[])

    def test_125_page_document_access(self):
        import fitz
        import server as s
        from parsing_store import parse_document
        path=s.FILES/'large.pdf'
        pdf=fitz.open()
        for i in range(125):
            page=pdf.new_page();page.insert_textbox(fitz.Rect(35,35,555,400),f'Page {i+1}. '+('Digital reading evidence and capacity allocation. '*35),fontsize=11)
        pdf.save(path);pdf.close()
        parse_document(path,'large','125-page-fixture.pdf','largehash',path.stat().st_size)
        self.assertEqual(self.client.get('/api/documents/large').json()['page_count'],125)
        self.assertEqual(self.client.get('/api/documents/large/pages/125').status_code,200)
        image=self.client.get('/api/documents/large/pages/125/image?dpi=50')
        self.assertEqual(image.status_code,200)
        self.assertTrue(image.headers['content-type'].startswith('image/'))


# Avoid discovering the imported base test class twice.
del WorkbenchTests
