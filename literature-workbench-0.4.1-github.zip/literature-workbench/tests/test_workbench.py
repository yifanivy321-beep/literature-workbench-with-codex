"""Isolated DB regression tests. Model responses below are SIMULATED, not live acceptance."""
import asyncio
import json
import sqlite3
import sys
import tempfile
import unittest
import gc
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import fitz
import server as s
import pdf_pipeline as pipeline
import workbench_api as api
from parsing_store import migrate_and_audit,parse_document
from fastapi import FastAPI
from fastapi.testclient import TestClient
from codex_adapter import CodexCliAdapter,classify_error,create_adapter
from codex_rpc import CodexRpc

class SimulatedAdapter:
    def probe(self):return dict(available=True,logged_in=True,executable='simulated',state='AUTHENTICATED',reason='SIMULATION')
class SimulatedRpc:
    prompts=[]
    calls=[]
    async def __aenter__(self):return self
    def __init__(self,*args):pass
    async def __aexit__(self,*args):pass
    async def call(self,method,params):return {'account':{'type':'simulated'}}
    async def models(self):return [dict(model='sim-A',displayName='Simulated A',inputModalities=['text','image'],isDefault=True,hidden=False,supportedReasoningEfforts=[{'reasoningEffort':'low'}])]
    async def generate(self,prompt,schema,cwd,model,effort,image):
        self.prompts.append(prompt);self.calls.append((model,effort,image))
        yield {'type':'status','actual_model':model or 'sim-default'}
        text=json.dumps(dict(answer='Simulated answer $x^2$.',citations=[dict(page=1,quote='Evidence statement.',confidence=.9),dict(page=1,quote='Fabricated quote',confidence=.9)],warnings=[]))
        for stop in (20,40,len(text)):yield {'type':'delta','item_id':'x','raw':text[:stop]}
        yield {'type':'final','text':text}

class WorkbenchTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='workbench-regression-')
        self.original=(s.DATA,s.FILES,s.DB_PATH)
        s.DATA=Path(self.tmp.name);s.FILES=s.DATA/'documents';s.DB_PATH=s.DATA/'workbench.sqlite3'
        s.init_db();migrate_and_audit()
        pdf=fitz.open();p=pdf.new_page();p.insert_text((50,60),'Evidence statement. Revenue is bounded by available capacity.');
        self.path=s.FILES/'doc.pdf';pdf.save(self.path);pdf.close()
        parse_document(self.path,'doc','fixture.pdf','uniquehash',self.path.stat().st_size)
        self.client=TestClient(s.app)
        self.conv=self.client.post('/api/conversations',json={'document_id':'doc','title':'Regression'}).json()['id']
    def tearDown(self):
        self.client.close();s.DATA,s.FILES,s.DB_PATH=self.original;gc.collect();self.tmp.cleanup()
    def simulated(self):
        app=FastAPI();api.install_routes(app)
        return TestClient(app)
    def question(self,**kwargs):
        body=dict(document_id='doc',conversation_id=self.conv,question='Explain the bound',context_mode='page',page_number=1,parse_revision=1,model='sim-A');body.update(kwargs);return body

    def test_scan_copyright_bypass(self):
        pdf=fitz.open();page=pdf.new_page();pix=fitz.Pixmap(fitz.csRGB,fitz.IRect(0,0,300,400),False);pix.clear_with(255)
        page.insert_image(page.rect,pixmap=pix);page.insert_text((40,page.rect.height-20),'Copyright 2001 All Rights Reserved.')
        result=pipeline.analyze(page);self.assertTrue(result['needs_ocr']);self.assertEqual(result['native_body_chars'],0);pdf.close()
    def test_union_area_not_double_counted(self):
        self.assertEqual(pipeline.union_area([(0,0,100,100),(0,0,100,100)],fitz.Rect(0,0,100,100)),10000)
    def test_blank_native_and_hybrid(self):
        pdf=fitz.open();blank=pdf.new_page();self.assertEqual(pipeline.analyze(blank)['page_kind'],'blank')
        p=pdf.new_page();p.insert_textbox(fitz.Rect(30,30,565,170),'Reliable digital text '*40,fontsize=10)
        self.assertFalse(pipeline.analyze(p)['needs_ocr'])
        pix=fitz.Pixmap(fitz.csRGB,fitz.IRect(0,0,300,400),False);pix.clear_with(200)
        p.insert_image(fitz.Rect(0,180,595,842),pixmap=pix)
        self.assertEqual(pipeline.analyze(p)['page_kind'],'hybrid');pdf.close()
    def test_no_engine_records_error(self):
        pdf=fitz.open();page=pdf.new_page();pix=fitz.Pixmap(fitz.csRGB,fitz.IRect(0,0,300,400),False);pix.clear_with(255);page.insert_image(page.rect,pixmap=pix)
        result=pipeline.parse_page(page,dict(available=False,code='OCR_MISSING'));self.assertEqual(result['error_code'],'OCR_MISSING');self.assertEqual(result['effective_text'],'');pdf.close()
    def test_reparse_preserves_relations_and_id(self):
        self.client.post('/api/bookmarks',json={'document_id':'doc','page_number':1,'label':'keep'})
        self.client.post('/api/annotations',json={'document_id':'doc','page_number':1,'selected_text':'Evidence','note':'keep'})
        with s.db() as c:c.execute('INSERT INTO messages(id,conversation_id,role,content,created_at) VALUES(?,?,?,?,?)',('old',self.conv,'assistant','Saved answer',s.NOW()))
        parse_document(self.path,'doc','fixture.pdf','uniquehash',self.path.stat().st_size)
        with s.db() as c:
            for table in ('documents','conversations','messages','annotations','bookmarks'):self.assertEqual(c.execute('SELECT COUNT(*) FROM '+table).fetchone()[0],1)
            self.assertEqual(c.execute('SELECT parse_revision FROM documents').fetchone()[0],2)
            self.assertEqual(c.execute('SELECT COUNT(*) FROM page_revisions').fetchone()[0],2)
    def test_failed_reparse_retains_previous(self):
        with patch.object(pipeline,'parse_page',return_value=dict(page_number=1,error_code='OCR_TIMEOUT',error_message='timeout',ocr_status='failed')):
            parse_document(self.path,'doc','fixture.pdf','uniquehash',self.path.stat().st_size)
        with s.db() as c:
            p=c.execute('SELECT * FROM pages').fetchone();self.assertIn('Evidence',p['effective_text']);self.assertEqual(p['error_code'],'OCR_TIMEOUT')
            self.assertEqual(c.execute('SELECT parse_status FROM documents').fetchone()[0],'needs_ocr')
    def test_search_uses_effective_text(self):
        with s.db() as c:c.execute("UPDATE pages SET raw_text='Copyright',ocr_text='Wrong precedence',effective_text='OCR body phrase',text_source='ocr'")
        result=self.client.get('/api/search',params={'document_id':'doc','q':'OCR body'}).json();self.assertIn('OCR body',result[0]['snippet'])
        self.assertEqual(self.client.get('/api/search',params={'document_id':'doc','q':'Copyright'}).json(),[])
    def test_restart_does_not_repopulate_nonbody(self):
        with s.db() as c:c.execute("UPDATE pages SET effective_text='',page_kind='non_body',raw_text='Copyright'")
        s.init_db()
        with s.db() as c:self.assertEqual(c.execute('SELECT effective_text FROM pages').fetchone()[0],'')
    def test_invalid_source_selection_revision_and_conversation(self):
        client=self.simulated()
        self.assertEqual(client.post('/api/ask',json=self.question(parse_revision=99)).status_code,409)
        r=client.post('/api/ask',json=self.question(context_mode='selection',selected_text='Made up quotation'));self.assertEqual(r.status_code,400)
        with s.db() as c:c.execute("UPDATE conversations SET document_id=NULL WHERE id=?",(self.conv,))
        self.assertEqual(client.post('/api/ask',json=self.question()).status_code,400)
    def test_simulated_stream_history_model_and_citations(self):
        with s.db() as c:c.execute('INSERT INTO messages(id,conversation_id,role,content,created_at) VALUES(?,?,?,?,?)',('prior',self.conv,'user','Previous assumption question',s.NOW()))
        with patch.object(api,'create_adapter',return_value=SimulatedAdapter()),patch.object(api,'CodexRpc',SimulatedRpc):
            client=self.simulated();response=client.post('/api/ask',json=self.question())
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.text.count('event: done'),1)
        self.assertIn('event: delta',response.text)
        final=json.loads(response.text.split('event: done\ndata: ')[1].split('\n\n')[0])
        self.assertEqual(final['requested_model'],'sim-A');self.assertEqual(final['actual_model'],'sim-A')
        self.assertEqual(len(final['citations']),1);self.assertIn('Previous assumption question',SimulatedRpc.prompts[-1])
        deltas=[json.loads(block.split('data: ')[1])['text'] for block in response.text.split('\n\n') if block.startswith('event: delta')]
        self.assertEqual(''.join(deltas),final['answer'])
        with s.db() as c:self.assertEqual(c.execute("SELECT COUNT(*) FROM messages WHERE role='assistant'").fetchone()[0],1)
    def test_model_patch_and_invalid_model_classification(self):
        client=self.simulated();r=client.patch('/api/conversations/'+self.conv,json={'model':'chosen-model','reasoning_effort':'low'})
        self.assertEqual(r.json()['model'],'chosen-model');self.assertEqual(classify_error('invalid model id'),'MODEL_UNAVAILABLE')
    def test_explicit_default_does_not_reuse_previous_model(self):
        with s.db() as c:c.execute("UPDATE conversations SET model='previous-model' WHERE id=?",(self.conv,))
        with patch.object(api,'create_adapter',return_value=SimulatedAdapter()),patch.object(api,'CodexRpc',SimulatedRpc):
            result=self.simulated().post('/api/ask',json=self.question(model=None)).text
        final=json.loads(result.split('event: done\ndata: ')[1].split('\n\n')[0]);self.assertIsNone(final['requested_model']);self.assertIsNone(SimulatedRpc.calls[-1][0])
    def test_column_order_never_interleaves(self):
        lines=[dict(text='Left first',bbox=[10,100,270,110]),dict(text='Right first',bbox=[320,100,580,110]),dict(text='Left second',bbox=[10,120,270,130]),dict(text='Right second',bbox=[320,120,580,130])]
        self.assertEqual([b['text'] for b in pipeline.reading_order(lines,600)],['Left first','Left second','Right first','Right second'])
    def test_hybrid_region_merge_prefers_reliable_native(self):
        native=[dict(text='Reliable native text',bbox=[0,0,100,20],source='native')]
        ocr=[dict(text='Corrupted native text',bbox=[0,0,100,20],source='ocr'),dict(text='Scanned body',bbox=[0,100,100,120],source='ocr')]
        merged=pipeline.merge_regions(native,ocr)
        self.assertEqual({b['text'] for b in merged},{'Reliable native text','Scanned body'})
    def test_rotation_crop_coordinate_roundtrip(self):
        pdf=fitz.open();p=pdf.new_page(width=650,height=850);p.set_cropbox(fitz.Rect(20,30,620,820))
        rect=fitz.Rect(100,100,250,120)
        for angle in (0,90,180,270):
            p.set_rotation(angle);restored=(rect*p.rotation_matrix)*p.derotation_matrix
            self.assertTrue(all(abs(a-b)<1e-6 for a,b in zip(rect,restored)))
        pdf.close()
    def test_cli_global_parameter_and_model_argument(self):
        cmd=CodexCliAdapter('native.exe').command(Path('中文 路径.json'),'中文 workdir','chosen')
        self.assertLess(cmd.index('-a'),cmd.index('exec'));self.assertEqual(cmd[cmd.index('--model')+1],'chosen');self.assertEqual(cmd[-1],'-')
    def test_private_database_not_served(self):
        self.assertEqual(self.client.get('/.workbench-data/workbench.sqlite3').status_code,404)
    def test_migration_backup_preserves_old_database(self):
        with s.db() as c:c.execute('PRAGMA user_version=2')
        s.init_db()
        backups=list((s.DATA/'backups').glob('pre-v3-*.sqlite3'));self.assertTrue(backups)
        with sqlite3.connect(backups[-1],factory=s.WorkbenchConnection) as c:self.assertEqual(c.execute('SELECT COUNT(*) FROM conversations').fetchone()[0],1)
    def test_cancelled_job_cannot_activate_revision(self):
        with s.db() as c:c.execute("INSERT INTO parse_jobs(id,document_id,scope,stage,status,revision,created_at) VALUES('cancel','doc','all','queued','cancelled',2,?)",(s.NOW(),))
        result=parse_document(self.path,'doc','fixture.pdf','uniquehash',self.path.stat().st_size,job_id='cancel')
        self.assertTrue(result['cancelled'])
        with s.db() as c:self.assertEqual(c.execute('SELECT parse_revision FROM documents').fetchone()[0],1)
    def test_simulated_protocol_complete_does_not_duplicate(self):
        class FixtureRpc(CodexRpc):
            def __init__(self):super().__init__('fixture');self.proc=type('Proc',(),{'returncode':0})()
            async def call(self,method,params,timeout=30):
                if method=='thread/start':return {'thread':{'id':'t'},'model':'fixture-model'}
                if method=='turn/start':
                    for e in [
                        {'method':'item/agentMessage/delta','params':dict(threadId='t',turnId='u',itemId='a',delta='hello')},
                        {'method':'item/completed','params':dict(threadId='t',turnId='u',item=dict(type='agentMessage',id='a',text='hello'))},
                        {'method':'turn/completed','params':dict(threadId='t',turn=dict(id='u',status='completed'))}]:await self.events.put(e)
                    return {'turn':{'id':'u'}}
        async def run():
            events=[e async for e in FixtureRpc().generate('fixture',{},'/tmp')]
            self.assertEqual([e['raw'] for e in events if e['type']=='delta'],['hello'])
            self.assertEqual([e['text'] for e in events if e['type']=='final'],['hello'])
        asyncio.run(run())
    def test_cancelled_ocr_process_is_released(self):
        info=pipeline.engine_info()
        pdf=fitz.open();page=pdf.new_page();pix=fitz.Pixmap(fitz.csRGB,fitz.IRect(0,0,300,400),False);pix.clear_with(255);page.insert_image(page.rect,pixmap=pix)
        with self.assertRaises(pipeline.ParseCancelled):pipeline.parse_page(page,info,force=True,cancelled=lambda:True)
        pdf.close()

    def test_simulated_request_stop_releases_stream_without_answer(self):
        class WaitingRpc(SimulatedRpc):
            released=False
            async def __aexit__(self,*args):self.released=True;WaitingRpc.released=True
            async def generate(self,*args):
                yield {'type':'status','actual_model':'sim-A'}
                await asyncio.Event().wait()
        class ConnectedRequest:
            async def is_disconnected(self):return False
        async def run():
            app=FastAPI();api.install_routes(app)
            ask=next(r.endpoint for r in app.routes if r.path=='/api/ask')
            stop=next(r.endpoint for r in app.routes if r.path=='/api/requests/{request_id}/cancel')
            response=await ask(api.Ask(**self.question()),ConnectedRequest())
            first=await anext(response.body_iterator)
            request_id=json.loads(first.split('data: ')[1])['request_id']
            seen=[]
            async def consume():
                async for event in response.body_iterator:seen.append(event)
            consumer=asyncio.create_task(consume())
            await asyncio.sleep(.05)
            self.assertTrue((await stop(request_id))['cancelled'])
            await asyncio.wait_for(consumer,2)
            self.assertTrue(WaitingRpc.released)
            self.assertTrue(any('event: stopped' in e for e in seen))
            self.assertFalse(any('event: done' in e for e in seen))
            with s.db() as conn:
                self.assertEqual(conn.execute("SELECT COUNT(*) FROM messages WHERE role='assistant'").fetchone()[0],0)
                self.assertEqual(conn.execute('SELECT generation_status FROM messages').fetchone()[0],'stopped_or_failed')
        with patch.object(api,'create_adapter',return_value=SimulatedAdapter()),patch.object(api,'CodexRpc',WaitingRpc):asyncio.run(run())

class RealLocalProtocolTest(unittest.TestCase):
    def test_actual_handshake_and_managed_cleanup_no_model_request(self):
        async def run():
            a=create_adapter()
            async with CodexRpc(a.executable) as rpc:
                result=await rpc.call('account/read',{'refreshToken':False});proc=rpc.proc
                self.assertIn('account',result)
            self.assertIsNotNone(proc.returncode)
        asyncio.run(run())

if __name__=='__main__':unittest.main(verbosity=2)

