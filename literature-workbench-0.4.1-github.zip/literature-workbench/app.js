const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const state = { document: null, documentUrl: null, conversation: null, page: 1, zoom: 100, fitWidth: false, split: 38, codex: null, serviceOk: false, selectedText: '', language: localStorage.getItem('workbench-language') || 'zh' };

function toast(message) {
  const node = $('#toast'); node.textContent = message; node.classList.add('show');
  setTimeout(() => node.classList.remove('show'), 3000);
}
async function api(path, options = {}) {
  const response = await fetch(path, options);
  if (!response.ok) { let message = `${response.status} ${response.statusText}`; try { const data = await response.json(); message = Array.isArray(data.detail) ? data.detail.map(item=>item.msg).join('; ') : typeof data.detail === 'object' ? `${data.detail.code}: ${data.detail.message}` : (data.detail || message); } catch {} throw new Error(message); }
  return response;
}
function localizedError(value){
  if(state.language!=='en')return value;
  const messages={AUTH_REQUIRED:'Sign in with codex login, then recheck.',AUTH_EXPIRED:'Authentication expired; sign in again.',CLI_MISSING:'Set the native Codex executable path.',TRANSPORT_FAILED:'Connection or protocol failed; check diagnostics.',MODEL_UNAVAILABLE:'Selected model is unavailable; choose another explicitly.',QUOTA_EXCEEDED:'Account usage limit reached.',TEXT_UNAVAILABLE:'No reliable body text; reparse or explicitly use an image.',INVALID_SOURCE:'Selection, page, block or document does not match the stored source.',STALE_REVISION:'Parsing revision changed; select text again.',IMAGE_UNSUPPORTED:'Image input has not been confirmed for the selected model.',EFFORT_UNSUPPORTED:'Reasoning effort is unsupported for this model.'};
  const code=Object.keys(messages).find(k=>String(value).includes(k));return code?`${code}: ${messages[code]}`:value;
}
function showError(error) { toast(localizedError(error.message || String(error))); }
function setConnection() {
  const node = $('#connectionState');
  node.title=state.codex?.reason||'';
  if(state.codex?.state && !['AUTH_REQUIRED','READY','AUTHENTICATED'].includes(state.codex.state)){node.textContent=`Codex ${state.codex.state}`;return;}
  if (state.language === 'en') {
    if (state.codex?.logged_in) node.textContent = state.codex.state === 'READY' ? 'Codex authenticated · model untested' : 'Codex signed in · protocol untested';
    else if (state.codex?.available) node.innerHTML = '<i class="amber-dot"></i> Codex sign-in needed';
    else node.innerHTML = '<i></i> Codex unavailable';
  } else if (state.codex?.logged_in) node.textContent = state.codex.state === 'READY' ? 'Codex 已认证 · 模型待测' : 'Codex 已登录 · 协议待测';
  else if (state.codex?.available) node.innerHTML = '<i class="amber-dot"></i> Codex 未登录';
  else node.innerHTML = '<i></i> Codex 不可用';
}
function setLanguage(language) {
  state.language = language; localStorage.setItem('workbench-language', language);
  const en = language === 'en'; document.documentElement.lang = en ? 'en' : 'zh-CN';
  $('#langBtn').textContent = en ? 'EN / 中' : '中 / EN';
  $('.panel-heading h1').textContent = en ? 'Reading chat' : '阅读对话';
  $('#libraryBtn span').textContent = en ? 'Library' : '文献库';
  $('#searchBtn span').textContent = en ? 'Search' : '搜索'; $('#settingsBtn span').textContent = en ? 'Settings' : '设置';
  $('#openBtn').textContent = en ? '+ Open paper' : '＋ 打开文献';
  $('#renameBtn').textContent = en ? 'Rename' : '重命名';
  $('.live-pill').lastChild.textContent = en ? ' Local session' : ' 本地会话';
  $('#contextLabel').textContent = en ? 'Context' : '上下文';
  const modes = en ? ['Selected text','Current page','Full text search','Page range'] : ['选中内容','当前页面','全文检索','指定范围'];
  [...$('#contextMode').options].forEach((option, i) => option.textContent = modes[i]);
  $('#questionInput').placeholder = en ? 'Ask about the paper, or select text first…' : '针对文献提问，或先选中一段文本…';
  $('#composerHint').textContent = en ? 'Enter to send · Shift + Enter for a new line' : 'Enter 发送 · Shift + Enter 换行';
  $('#dropZone h2').textContent = en ? 'Drop a PDF here' : '将 PDF 拖到这里';
  $('#dropZone .drop-content p').firstChild.textContent = en ? 'or ' : '或 ';
  $('#browseBtn').textContent = en ? 'Choose a local file' : '从本机选择文件';
  $('#dropZone small').textContent = en ? 'Files are processed on this computer and are not uploaded' : '文件仅在本机处理，不会上传到云端';
  const cards = en ? ['Quick summary','Explain concept','Find assumptions','Outline method'] : ['快速总结','概念解释','寻找假设','方法梳理'];
  const quickPrompts = en ? [
    'Summarize the research question, method, and conclusion in three sentences.',
    'Explain the central concept on this page and its role in the paper.',
    'Identify the key assumptions and their possible limitations.',
    'Outline the research design and identification strategy.'
  ] : [
    '请用三句话概括这篇文献的研究问题、方法和结论。',
    '请解释当前页面的核心概念，并指出它在全文中的作用。',
    '请找出作者依赖的关键假设，并说明可能的局限。',
    '请梳理这篇文献的研究设计和识别策略。'
  ];
  $$('.quick-grid button').forEach((button, i) => { button.childNodes[1].textContent = cards[i]; button.dataset.prompt = quickPrompts[i]; });
  $('#contextCard .context-card-head span').firstChild.textContent = en ? 'Selected text · page ' : '已选文本 · 第 ';
  const actions = en ? ['Explain','Summarize','Find assumptions','Add note'] : ['解释含义','总结这段','找出假设','添加批注'];
  const actionPrompts = en ? ['Explain the meaning of this passage.','Summarize this passage.','Identify assumptions in this passage.'] : ['请解释这段文字的含义。','请总结这段文字。','请指出这段文字中的假设。'];
  $$('.context-actions button').forEach((button, i) => { button.textContent = actions[i]; if (i < 3) button.dataset.prompt = actionPrompts[i]; });
  $('#pageTextDrawer .page-text-head span').firstChild.textContent = en ? 'Page ' : '第 ';
  $('#showPageText').textContent = en ? 'Show extracted page text' : '显示本页解析文本';
  $('#libraryModal h2').textContent = en ? 'Local library' : '本机文献库';
  $('#searchModal h2').textContent = en ? 'Full-text search' : '全文检索';
  $('#chatFeed .welcome-block h2') && ($('#chatFeed .welcome-block h2').textContent = en ? 'Start with a paper' : '从一篇文献开始');
  $('#chatFeed .welcome-block p') && ($('#chatFeed .welcome-block p').textContent = en ? 'Drop a PDF or open one from this computer. Text extraction and search stay local; Codex questions require a signed-in local CLI.' : '拖入 PDF 或点击右上角打开文献。文本检索与页面提取在本机运行；Codex 问答需要本机 CLI 已登录。');
  $('#settingsModal h2').textContent = en ? 'Settings and diagnostics' : '设置与诊断';
  $('#resetSplitBtn').textContent = en ? 'Restore default split' : '恢复默认分栏';
  $('#refreshDiagnostics').textContent = en ? 'Check environment' : '重新检查环境';
  if (state.serviceOk) $('#footerStatus').textContent = en ? 'Local service connected' : '本地服务已连接';
  $('#searchInput').placeholder = en ? 'Search terms' : '输入关键词'; $('#runSearch').textContent = en ? 'Search' : '搜索';
  setConnection();
  if (typeof updateNewLabels === 'function') updateNewLabels(); if(typeof refreshDocumentLabels==='function')refreshDocumentLabels();
}
async function refreshHealth() {
  try {
    const data = await (await api('/api/health')).json(); state.codex = await (await api('/api/codex/status')).json(); state.serviceOk = true; setConnection();
    $('#footerStatus').textContent = state.language === 'en' ? 'Local service connected' : '本地服务已连接';
    if (data.ocr.tesseract) { $('#ocrStatus').textContent = 'Tesseract 可用'; }
    else $('#ocrStatus').textContent = '未安装 OCR';
    refreshDocumentLabels();
  } catch (error) { state.serviceOk = false; $('#footerStatus').textContent = state.language === 'en' ? 'Local service unavailable' : '本地服务连接失败'; setConnection(); }
}
function showDocument(doc) {
  state.abortController?.abort();
  state.document = doc; state.page = 1; state.selectedText = ''; state.parseRevision = doc.parse_revision || null; state.selectionBlocks = []; state.imageBBox = null; state.conversation = null;
  localStorage.setItem('workbench-last-document', doc.id);
  $('#docName').textContent = doc.file_name;
  $('#parseSummary').textContent = `${doc.page_count} 页 · ${doc.parse_status === 'needs_ocr' ? '扫描件，等待 OCR' : (doc.parse_status === 'partial' ? '部分页面需 OCR' : '文本已提取')}`;
  $('#documentView').classList.remove('hidden'); $('#dropZone').classList.add('hidden');
  let savedPosition={};try{savedPosition=JSON.parse(localStorage.getItem('reading-position:'+doc.id)||'{}');}catch{}
  state.fitWidth = savedPosition.fit??true; if (window.workbenchReader) window.workbenchReader.open(doc.id).catch(showError);
  $('#totalPages').textContent = doc.page_count; $('#pageInput').value = 1;
  const stats=doc.page_stats;
  $('#readerStatus').textContent = stats ? `${stats.usable||0} ${state.language==='en'?'usable pages':'页正文可用'} · ${stats.non_body||0} ${state.language==='en'?'non-body':'页非正文'} · ${stats.failed||0} ${state.language==='en'?'failed':'页失败'}` : (doc.parse_status === 'needs_ocr' ? 'PDF 已打开 · 等待 OCR' : (doc.parse_status === 'partial' ? '部分页面未识别' : '有效正文已索引'));
  $('#indexStatus').textContent = doc.parse_status === 'needs_ocr' ? '扫描件' : (doc.parse_status === 'partial' ? '部分完成' : '已完成');
  $('#ocrStatus').textContent = doc.ocr_status === 'unavailable' ? '缺少 Tesseract' : (doc.ocr_status === 'completed' ? '已运行' : (doc.ocr_status === 'partial' ? '部分完成' : (doc.ocr_status === 'failed' ? 'OCR 失败' : '无需 OCR')));
  $('#showPageText').classList.remove('hidden');
  $('#pageTextDrawer').classList.add('hidden');
  $('#contextCard').classList.add('hidden');
  loadBookmarks().catch(showError);
  $('#chatFeed').innerHTML = '';
  if (doc.parse_status === 'needs_ocr') toast('已导入扫描版 PDF；当前环境缺少 Tesseract，页面图像可读，文本问答不可用。');
  else if (doc.parse_status === 'partial') toast('部分页面未获得可靠文本；问答时会显示上下文不完整警告。');
  createConversation(doc.id).catch(showError);
  refreshDocumentLabels();
}
async function createConversation(documentId, title = '阅读会话') {
  const existing = documentId ? await (await api(`/api/conversations?document_id=${encodeURIComponent(documentId)}`)).json() : [];
  const data = existing[0] || await (await api('/api/conversations', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ document_id: documentId, title }) })).json();
  if(state.document?.id!==documentId)return;
  state.conversation = data; restoreModel(data.model || state.defaultModel || ''); if(data.reasoning_effort)$('#effortSelect').value=data.reasoning_effort; $('#sessionName').textContent = data.title;
  await restoreMessages(data.id);
}
async function restoreMessages(id) {
  const rows = await (await api(`/api/conversations/${id}/messages`)).json();
  if(state.conversation?.id!==id)return;
  $('#chatFeed').innerHTML = '';
  for (const row of rows) {
    const bubble = appendMessage(row.role, row.content, false); if (row.role === 'assistant') { let meta = {}; try { meta = JSON.parse(row.context_json); } catch {} addAnswerDetails(bubble, {...meta, requested_model: row.requested_model, actual_model: row.actual_model}); }
    for (const citation of (row.citations || [])) { const link = document.createElement('button'); link.className = 'citation'; link.textContent = `第 ${citation.page} 页 · ${citation.quote}`; link.onclick = () => { window.workbenchReader.pendingQuote = citation.quote; goToPage(citation.page); }; bubble.append(document.createElement('br'), link); }
  }
}
function appendMessage(role, text, scroll = true) {
  const message = document.createElement('div'); message.className = `message ${role}`;
  const bubble = document.createElement('div'); bubble.className = 'bubble';
  if (role === 'assistant') bubble.innerHTML = renderMarkdown(text); else bubble.textContent = text;
  message.appendChild(bubble); $('#chatFeed').appendChild(message);
  if (scroll) $('#chatFeed').scrollTop = $('#chatFeed').scrollHeight;
  return bubble;
}
function renderMarkdown(source) {
  const holder = document.createElement('div');
  const formulas = [];
  const input = String(source).replace(/\$\$([\s\S]*?)\$\$|\$([^$\n]+)\$|\\\[([\s\S]*?)\\\]|\\\((.*?)\\\)/g, (match, block, inline, bracket, paren) => {
    const marker = `MATHPLACEHOLDER${formulas.length}END`;
    formulas.push({text:block ?? inline ?? bracket ?? paren,display:block!==undefined||bracket!==undefined,original:match});return marker;
  });
  holder.innerHTML = DOMPurify.sanitize(marked.parse(input), {FORBID_TAGS:['style','iframe','form','input'],FORBID_ATTR:['style']});
  const walk=document.createTreeWalker(holder,NodeFilter.SHOW_TEXT);const nodes=[];while(walk.nextNode())nodes.push(walk.currentNode);
  for(const node of nodes){
    if(node.parentElement.closest('code,pre')){node.textContent=node.textContent.replace(/MATHPLACEHOLDER(\d+)END/g,(_,id)=>formulas[Number(id)].original);continue;}
    const regex=/MATHPLACEHOLDER(\d+)END/g;let found,last=0;const fragment=document.createDocumentFragment();
    while((found=regex.exec(node.textContent))){fragment.append(document.createTextNode(node.textContent.slice(last,found.index)));const span=document.createElement('span'),formula=formulas[Number(found[1])];try{katex.render(formula.text,span,{displayMode:formula.display,throwOnError:true,trust:false});}catch{span.textContent=formula.original;span.title='公式排版失败 / Math rendering failed';}fragment.append(span);last=regex.lastIndex;}
    if(last){fragment.append(document.createTextNode(node.textContent.slice(last)));node.replaceWith(fragment);}
  }
  holder.querySelectorAll('a').forEach(a=>{a.rel='noopener noreferrer';a.target='_blank';});
  return holder.innerHTML;
}

function partialJsonString(raw, key) {
  const keyAt = raw.indexOf(`"${key}"`); if (keyAt < 0) return '';
  const colon = raw.indexOf(':', keyAt + key.length + 1); if (colon < 0) return '';
  const quote = raw.indexOf('"', colon + 1); if (quote < 0) return '';
  let output = ''; let escaped = false;
  for (let i = quote + 1; i < raw.length; i++) {
    const char = raw[i];
    if (escaped) {
      const map = { n: '\n', r: '\r', t: '\t', b: '\b', f: '\f', '"': '"', '\\': '\\', '/': '/' };
      if (char === 'u' && i + 4 < raw.length) { const value = Number.parseInt(raw.slice(i + 1, i + 5), 16); if (!Number.isNaN(value)) output += String.fromCharCode(value); i += 4; }
      else if (char === 'u') break;
      else output += map[char] ?? char;
      escaped = false;
    } else if (char === '\\') escaped = true;
    else if (char === '"') break;
    else output += char;
  }
  return output;
}
async function openPdf(file) {
  if (!file) return;
  if (Array.isArray(file) || (typeof FileList !== 'undefined' && file instanceof FileList)) {
    const files = [...file];
    for (let i = 0; i < files.length; i++) {
      $('#parseSummary').textContent = `导入队列 ${i + 1}/${files.length}：${files[i].name}`;
      try { await openPdf(files[i]); } catch (error) { toast(`${files[i].name}：${error.message}`); }
    }
    return;
  }
  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) throw new Error('格式不支持：请选择 PDF 文件');
  const data = new FormData(); data.append('file', file);
  $('#parseSummary').textContent = '正在上传到本机并解析…'; $('#footerStatus').textContent = '正在导入文献';
  await new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest(); xhr.open('POST', '/api/documents');
    xhr.upload.onprogress = (event) => { if (event.lengthComputable) $('#parseSummary').textContent = `正在传输到本机 · ${Math.round(event.loaded / event.total * 100)}%`; };
    xhr.onload = async () => {
      let result; try { result = JSON.parse(xhr.responseText); } catch { reject(new Error('本地服务返回了无法识别的结果')); return; }
      if (xhr.status < 200 || xhr.status >= 300) { $('#parseSummary').textContent = '导入失败'; reject(new Error(result.detail || '无法读取 PDF')); return; }
      try {
        if (result.duplicate) { showDocument(result); if (await askConfirm('文献已存在。是否保留原记录并重新解析？ / Reparse the existing document?')) await startReparse('all'); }
        else if (result.job_id) { $('#parseSummary').textContent = '文件已到达本机，正在提取页面文本…'; await pollImport(result.job_id); }
        else throw new Error('本地服务返回了缺少任务信息的结果');
        resolve();
      } catch (error) { reject(error); }
    };
    xhr.onerror = () => { $('#parseSummary').textContent = '导入失败'; reject(new Error('无法连接本地服务')); };
    xhr.send(data);
  });
  $('#fileInput').value = '';
}
async function pollImport(jobId) {
  const job = await (await api(`/api/jobs/${jobId}`)).json();
  $('#parseSummary').textContent = job.message || `正在解析 · ${job.progress}%`;
  if (job.status === 'completed' && job.document) { showDocument(job.document); $('#footerStatus').textContent = '文献已保存在本机'; return; }
  if (job.status === 'failed') { $('#parseSummary').textContent = '解析失败'; $('#footerStatus').textContent = job.message; throw new Error(job.message); }
  await new Promise(resolve => window.setTimeout(resolve, 450));
  return pollImport(jobId);
}
async function loadPageText() {
  if (!state.document) return;
  try {
    const page = await (await api(`/api/documents/${state.document.id}/pages/${state.page}`)).json();
    $('#textPageNumber').textContent = state.page;
    if(page.page_number!==state.page)return;
    state.parseRevision = page.parse_revision; $('#pageTextContent').textContent = page.effective_text || ''; $('#pageTextContent').title=`${page.page_kind} · ${page.text_source} · ${page.quality_reason || ''} ${page.error_message || ''}`; $('#pageTextContent').dataset.page = page.page_number;$('#pageTextContent').dataset.revision=page.parse_revision;
    $('#pageTextDrawer').classList.remove('hidden');
  } catch (error) { showError(error); }
}
function goToPage(page) {
  if (!state.document) return;
  const previous=state.page;
  state.page = Math.max(1, Math.min(state.document.page_count, Math.floor(Number(page)) || 1));
  if(previous!==state.page){state.selectedText='';state.selectionBlocks=[];state.imageBBox=null;$('#contextCard').classList.add('hidden');$('#pageTextDrawer').classList.add('hidden');}
  $('#pageInput').value = state.page;
  const zoom = state.fitWidth ? 'page-width' : state.zoom;
  window.workbenchReader?.draw(state.page, state.zoom, state.fitWidth).catch(showError);
  $('#readerStatus').textContent = `第 ${state.page} 页 / ${state.document.page_count} 页`;
}
async function sendQuestion(question) {
  if(state.abortController)return;
  const value = question.trim(); if (!value) return;
  if (!state.document) { toast('请先打开一篇文献'); return; }
  if (!state.conversation) { toast('会话正在准备，请稍后重试'); return; }
  if (state.codex?.logged_in && !state.contextDisclosureAccepted) {
    const allowed = await askConfirm('这次问答会把所选文本或检索到的文献片段交给本机 Codex CLI。实际处理位置取决于你的 Codex 模型/服务商设置；如果不是完全本地模型，片段可能发送到远端服务。是否允许本次会话发送？');
    if (!allowed) return;
    state.contextDisclosureAccepted = true;
  }
  let mode = $('#contextMode').value || 'selection';
  if (mode === 'selection' && !state.selectedText.trim()) mode = 'page';
  let pageEnd = null;
  if (mode === 'range') { const range = await askPrompt(`输入页码范围（1-${state.document.page_count}），最多 20 页，格式如 2-5`, `${state.page}-${Math.min(state.page + 4, state.document.page_count)}`); if (!range) return; if(!/^\d+(?:\s*-\s*\d+)?$/.test(range.trim()))return toast('请输入有效页码范围，例如 2-5');const parts=range.trim().split('-').map(Number);pageEnd=parts[1]||parts[0];if(parts[0]<1||pageEnd<parts[0]||pageEnd>state.document.page_count||pageEnd-parts[0]>19)return toast('页码范围无效或超过 20 页');state.range=parts; }
  appendMessage('user', value); $('#questionInput').value = '';
  const bubble = appendMessage('assistant', '正在连接 Codex…');
  state.abortController = new AbortController(); state.requestId=null;state.wasStopped=false;
  $('#sendBtn').textContent = '■'; $('#sendBtn').title = '停止生成';
  $('#sendBtn').onclick = stopGeneration;
  try {
    const response = await api('/api/ask', { method: 'POST', signal: state.abortController.signal, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: value, document_id: state.document.id, conversation_id: state.conversation.id, context_mode: mode, page_number: mode === 'range' ? state.range[0] : mode === 'selection' ? Number($('#selectionPage').textContent) || state.page : state.page, page_end: pageEnd, selected_text: mode === 'selection' ? state.selectedText : '', selection_block_ids: mode === 'selection' ? (state.selectionBlocks || []) : [], parse_revision: state.parseRevision || null, model: selectedModel(), reasoning_effort: $('#effortSelect').value || null, include_page_image: $('#includePageImage').checked, image_bbox: state.imageBBox || null, language: state.language }) });
    const reader = response.body.getReader(); const decoder = new TextDecoder(); let buffer = ''; let visible = ''; let finalAnswer = null;
    while (true) {
      const { value: chunk, done } = await reader.read(); if (done) break;
      buffer += decoder.decode(chunk, { stream: true });
      const events = buffer.split('\n\n'); buffer = events.pop() || '';
      for (const event of events) {
        const lines = event.split('\n'); const type = lines.find(x => x.startsWith('event:'))?.slice(6).trim();
        const payload = lines.filter(x => x.startsWith('data:')).map(x => x.slice(5).trim()).join('\n');
        if (!payload) continue;
        let parsed; try { parsed = JSON.parse(payload); } catch { continue; }
        if (type === 'delta') { visible += parsed.text || ''; bubble.textContent = visible || (state.language === 'en' ? 'Codex is preparing a grounded answer…' : 'Codex 正在整理依据并生成回答…'); $('#chatFeed').scrollTop = $('#chatFeed').scrollHeight; }
        if (type === 'done') finalAnswer = parsed; if (type === 'stopped') { bubble.textContent=parsed.message; state.wasStopped=true; } if (type === 'status') { if(parsed.request_id)state.requestId=parsed.request_id; state.generationModel = parsed.actual_model || parsed.requested_model || state.generationModel; }
        if (type === 'error') throw new Error(parsed.message || 'Codex 调用失败');
      }
    }
    if (finalAnswer) {
      bubble.innerHTML = renderMarkdown(finalAnswer.answer || visible || '未返回正文'); addAnswerDetails(bubble, finalAnswer);
      for (const citation of (finalAnswer.citations || [])) {
        const button = document.createElement('button'); button.className = 'citation'; button.textContent = `第 ${citation.page} 页 · ${citation.quote}`;
        button.onclick = () => { window.workbenchReader.pendingQuote = citation.quote; goToPage(citation.page); }; bubble.appendChild(document.createElement('br')); bubble.appendChild(button);
      }
      if (finalAnswer.warnings?.length) { const warning = document.createElement('div'); warning.className = 'citation-warning'; warning.textContent = finalAnswer.warnings.join('；'); bubble.appendChild(warning); }
    }
  } catch (error) { bubble.textContent = error.name === 'AbortError' ? '已停止生成。' : `${state.language==='en'?'Answer failed:':'回答未生成：'}${localizedError(error.message)}`; }
  finally { state.abortController = null; $('#sendBtn').textContent = '↑'; $('#sendBtn').title = '发送'; $('#sendBtn').onclick = () => sendQuestion($('#questionInput').value); }
}
function contextSelection() {
  const sel=window.getSelection();if(!sel?.rangeCount||sel.isCollapsed||!state.document)return;
  const range=sel.getRangeAt(0),reader=$('#pdfReader'),drawer=$('#pageTextContent');
  let selection='',page,revision,blockIds=[];
  if(reader.contains(range.startContainer)&&reader.contains(range.endContainer)){
    const pieces=[];
    for(const el of reader.querySelectorAll('.ocr-line')){
      if(!range.intersectsNode(el))continue;
      const part=document.createRange();part.selectNodeContents(el);
      if(range.compareBoundaryPoints(Range.START_TO_START,part)>0)part.setStart(range.startContainer,range.startOffset);
      if(range.compareBoundaryPoints(Range.END_TO_END,part)<0)part.setEnd(range.endContainer,range.endOffset);
      const text=part.toString();if(!text)continue;
      if(page!==undefined&&(page!==Number(el.dataset.page)||revision!==Number(el.dataset.revision)))return;
      pieces.push(text);blockIds.push(Number(el.dataset.blockId));page=Number(el.dataset.page);revision=Number(el.dataset.revision);
    }
    selection=pieces.join('\n').trim();
  }else if(drawer.contains(range.startContainer)&&drawer.contains(range.endContainer)){
    selection=range.toString().trim();page=Number(drawer.dataset.page);revision=Number(drawer.dataset.revision);
  }else return;
  if (!selection || selection.length < 3 || !state.document) return;
  state.selectionBlocks=blockIds;state.parseRevision=revision;
  state.selectedText = selection; $('#selectionSource').textContent=`${state.currentPageData?.text_source||'text'} · revision ${state.parseRevision}`;
  $('#selectionPage').textContent = page;
  $('#selectionText').textContent = `“${selection.slice(0, 360)}${selection.length > 360 ? '…' : ''}”`;
  $('#contextCard').classList.remove('hidden');
  $('#contextMode').value = 'selection';
}
async function showLibrary() {
  try {
    const docs = await (await api('/api/documents')).json(); const list = $('#libraryList'); list.innerHTML = '';
    if (!docs.length) { list.innerHTML = '<p class="empty-state">文献库为空。导入的 PDF、解析文本和会话只保存在本机。</p>'; }
    for (const doc of docs) {
      const row = document.createElement('div'); row.className = 'library-row';
      const main = document.createElement('main'); const name = document.createElement('strong'); name.textContent = doc.file_name; const meta = document.createElement('small'); meta.textContent = `${doc.page_count} 页 · ${doc.parse_status === 'needs_ocr' ? '需要 OCR' : '已解析'} · ${new Date(doc.created_at).toLocaleDateString()}`; main.append(name, meta);
      const open = document.createElement('button'); open.textContent = '打开'; open.onclick = async () => { const info = await (await api(`/api/documents/${doc.id}`)).json(); showDocument(info); $('#libraryModal').classList.add('hidden'); };
      const remove = document.createElement('button'); remove.className = 'delete-doc'; remove.textContent = '删除'; remove.onclick = async () => { if (!await askConfirm(`删除“${doc.file_name}”及其解析结果、会话和标注？此操作不可撤销。`)) return; try { await api(`/api/documents/${doc.id}`, { method: 'DELETE' }); showLibrary(); if (state.document?.id === doc.id) { state.document = null; state.conversation = null; localStorage.removeItem('workbench-last-document'); $('#docName').textContent = '尚未打开文献'; $('#parseSummary').textContent = '等待导入'; $('#sessionName').textContent = '未命名会话'; $('#chatFeed').innerHTML = ''; $('#documentView').classList.add('hidden'); $('#dropZone').classList.remove('hidden'); $('#pageTextDrawer').classList.add('hidden'); $('#showPageText').classList.add('hidden'); } } catch (error) { showError(error); } };
      row.append(main, open, remove); list.appendChild(row);
    }
    $('#libraryModal').classList.remove('hidden');
  } catch (error) { showError(error); }
}
async function runSearch() {
  if (!state.document) { toast('先导入文献后才能全文检索'); return; }
  const q = $('#searchInput').value.trim(); if (!q) return;
  try {
    const results = await (await api(`/api/search?document_id=${encodeURIComponent(state.document.id)}&q=${encodeURIComponent(q)}`)).json();
    const root = $('#searchResults'); root.innerHTML = '';
    if (!results.length) { root.innerHTML = '<p class="empty-state">没有找到匹配内容。</p>'; return; }
    for (const result of results) { const hit = document.createElement('div'); hit.className = 'search-hit'; const title = document.createElement('strong'); title.textContent = `第 ${result.page_number} 页`; const excerpt = document.createElement('p'); excerpt.textContent = result.snippet; const jump = document.createElement('button'); jump.textContent = '跳转'; jump.onclick = () => { goToPage(result.page_number); $('#searchModal').classList.add('hidden'); }; hit.append(title, excerpt, jump); root.appendChild(hit); }
  } catch (error) { showError(error); }
}

$('#openBtn').onclick = $('#browseBtn').onclick = () => $('#fileInput').click();
$('#fileInput').onchange = (event) => openPdf(event.target.files).catch(showError);
$('#dropZone').ondragover = (event) => { event.preventDefault(); $('#dropZone').classList.add('dragover'); };
$('#dropZone').ondragleave = () => $('#dropZone').classList.remove('dragover');
$('#dropZone').ondrop = (event) => { event.preventDefault(); $('#dropZone').classList.remove('dragover'); openPdf(event.dataTransfer.files).catch(showError); };
$('#sendBtn').onclick = () => sendQuestion($('#questionInput').value);
$('#questionInput').onkeydown = (event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendQuestion(event.target.value); } };
document.querySelectorAll('.quick-grid [data-prompt]').forEach((button) => { button.onclick = () => { $('#questionInput').value = button.dataset.prompt; $('#questionInput').focus(); }; });
document.querySelectorAll('.context-actions [data-prompt]').forEach((button) => { button.onclick = () => sendQuestion(button.dataset.prompt); });
$('#clearSelection').onclick = () => { state.selectedText = ''; $('#contextCard').classList.add('hidden'); };
$('#prevPage').onclick = () => goToPage(state.page - 1);
$('#nextPage').onclick = () => goToPage(state.page + 1);
$('#pageInput').onchange = () => goToPage($('#pageInput').value);
$('#pageInput').onkeydown = e => {if(e.key==='Enter'){e.preventDefault();goToPage(e.target.value);}};
$('#zoomIn').onclick = () => { state.fitWidth = false; state.zoom = Math.min(200, state.zoom + 10); $('#zoomValue').textContent = `${state.zoom}%`; if (state.document) goToPage(state.page); };
$('#zoomOut').onclick = () => { state.fitWidth = false; state.zoom = Math.max(50, state.zoom - 10); $('#zoomValue').textContent = `${state.zoom}%`; if (state.document) goToPage(state.page); };
$('#fitWidth').onclick = () => { state.fitWidth = true; $('#zoomValue').textContent = '适应宽度'; if (state.document) goToPage(state.page); };
$('#fullscreenBtn').onclick = () => $('#readerPanel').requestFullscreen?.();
$('#showPageText').onclick = loadPageText; $('#closePageText').onclick = () => $('#pageTextDrawer').classList.add('hidden');
$('#annotateSelection').onclick = async () => { if (!state.document || !state.selectedText) return; const note = await askPrompt('为选中文本添加批注'); if (note === null) return; try { await api('/api/annotations', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ document_id: state.document.id, page_number: Number($('#selectionPage').textContent) || state.page, selected_text: state.selectedText, note }) }); toast('批注已保存在本机'); } catch (error) { showError(error); } };
$('#newSessionBtn').onclick = async () => { try { state.conversation = await (await api('/api/conversations', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ document_id: state.document?.id || null, title: '新会话' }) })).json(); $('#sessionName').textContent = state.conversation.title; $('#chatFeed').innerHTML = ''; } catch (error) { showError(error); } };
$('#renameBtn').onclick = async () => { const title = (await askPrompt('会话名称', $('#sessionName').textContent))?.trim(); if (!title || !state.conversation) return; try { state.conversation = await (await api(`/api/conversations/${state.conversation.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title }) })).json(); $('#sessionName').textContent = title; } catch (error) { showError(error); } };
$('#langBtn').onclick = () => setLanguage(state.language === 'zh' ? 'en' : 'zh');
$('#libraryBtn').onclick = showLibrary; $('#closeLibrary').onclick = () => $('#libraryModal').classList.add('hidden');
async function loadDiagnostics() {
  $('#diagnosticData').textContent = state.language === 'en' ? 'Checking local environment…' : '正在检查本机环境…';
  try { const data = await (await api('/api/diagnostics')).json(); state.codex = await (await api('/api/codex/status')).json(); data.codex={...state.codex,reason:localizedError(state.codex.state+': '+state.codex.reason)}; $('#diagnosticData').textContent = JSON.stringify(data, null, 2); setConnection(); }
  catch (error) { $('#diagnosticData').textContent = `${state.language === 'en' ? 'Diagnostic request failed: ' : '诊断请求失败：'}${error.message}`; }
}
$('#settingsBtn').onclick = () => { $('#settingsModal').classList.remove('hidden'); loadDiagnostics(); };
$('#closeSettings').onclick = () => $('#settingsModal').classList.add('hidden');
$('#refreshDiagnostics').onclick = async () => { await api('/api/codex/probe', {method:'POST'}); refreshHealth(); loadDiagnostics(); refreshModelCatalog(true); };
$('#resetSplitBtn').onclick = () => { state.split = 38; localStorage.removeItem('workbench-split'); $('#conversationPanel').style.width = '38%'; $('#readerPanel').style.width = '62%'; toast(state.language === 'en' ? 'Default split restored' : '已恢复默认分栏'); };
$('#searchBtn').onclick = () => { $('#searchModal').classList.remove('hidden'); $('#searchInput').focus(); };
$('#searchPage').onclick = () => { if (!state.document) return toast('先导入文献'); $('#searchModal').classList.remove('hidden'); $('#searchInput').focus(); };
$('#closeSearch').onclick = () => $('#searchModal').classList.add('hidden'); $('#runSearch').onclick = runSearch;
$('#searchInput').onkeydown = (event) => { if (event.key === 'Enter') runSearch(); };
$('#splitter').onmousedown = () => { state.dragging = true; };
window.addEventListener('mouseup', () => { state.dragging = false; });
window.addEventListener('mousemove', (event) => { if (!state.dragging) return; state.split = Math.max(28, Math.min(55, event.clientX / window.innerWidth * 100)); $('#conversationPanel').style.width = `${state.split}%`; $('#readerPanel').style.width = `${100-state.split}%`; localStorage.setItem('workbench-split', String(state.split)); });
const savedSplit = Number(localStorage.getItem('workbench-split'));
if (savedSplit >= 28 && savedSplit <= 55) { state.split = savedSplit; $('#conversationPanel').style.width = `${savedSplit}%`; $('#readerPanel').style.width = `${100-savedSplit}%`; }
document.addEventListener('mouseup', contextSelection);
$('#bookmarkBtn').onclick = async () => {
  if (!state.document) return toast('先打开文献');
  try { await api('/api/bookmarks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ document_id: state.document.id, page_number: state.page, label: `第 ${state.page} 页` }) }); toast(`已将第 ${state.page} 页加入书签`); }
  catch (error) { showError(error); }
};
async function loadBookmarks() {
  if (!state.document) return;
  const list = await (await api(`/api/documents/${state.document.id}/bookmarks`)).json();
  $('#bookmarkBtn').title = list.length ? `书签（${list.length}）· 当前第 ${state.page} 页` : '添加书签';
  $('#bookmarkBtn').onclick = async () => {
    if (!list.length) return createBookmark();
    const options = list.map((item, i) => `${i+1}. 第 ${item.page_number} 页 · ${item.label}`).join('\n');
    const answer = await askPrompt(`输入序号跳转；输入 + 页码可添加书签：\n${options}`, '1');
    if (answer?.startsWith('+')) { const p = Number(answer.slice(1)); goToPage(p); return createBookmark(p); }
    const item = list[Number(answer)-1]; if (item) goToPage(item.page_number);
  };
}
async function createBookmark(page = state.page) {
  try { await api('/api/bookmarks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ document_id: state.document.id, page_number: page, label: `第 ${page} 页` }) }); toast(`已将第 ${page} 页加入书签`); await loadBookmarks(); }
  catch (error) { showError(error); }
}
$('#exportBtn').onclick = async () => {
  if (!state.conversation) return toast('当前没有可导出的会话');
  try { const response = await api(`/api/conversations/${state.conversation.id}/export.md`); const blob = await response.blob(); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `literature-session-${state.conversation.id.slice(0,8)}.md`; a.click(); URL.revokeObjectURL(a.href); }
  catch (error) { showError(error); }
};
window.addEventListener('keydown', (event) => {
  if (event.ctrlKey && (event.key === '+' || event.key === '=')) { event.preventDefault(); $('#zoomIn').click(); }
  else if (event.ctrlKey && event.key === '-') { event.preventDefault(); $('#zoomOut').click(); }
  else if (event.ctrlKey && event.key === '0') { event.preventDefault(); $('#fitWidth').click(); }
});
$('#readerPanel').addEventListener('wheel', (event) => { if (event.ctrlKey) { event.preventDefault(); (event.deltaY < 0 ? $('#zoomIn') : $('#zoomOut')).click(); } }, { passive: false });
refreshHealth();
setLanguage(state.language);
(async () => {
  try {
    const id = localStorage.getItem('workbench-last-document'); if (!id) return;
    const response = await fetch(`/api/documents/${encodeURIComponent(id)}`); if (!response.ok) return;
    showDocument(await response.json());
  } catch { /* Keep a fresh import available if no saved document can be restored. */ }
})();
$('#sessionName').title = '点击切换已保存会话';
$('#sessionName').style.cursor = 'pointer';
$('#sessionName').onclick = async () => {
  try {
    const sessions = await (await api(`/api/conversations${state.document ? `?document_id=${encodeURIComponent(state.document.id)}` : ''}`)).json();
    if (!sessions.length) return toast('还没有保存的会话');
    const options = sessions.map((session, i) => `${i + 1}. ${session.title} · ${new Date(session.updated_at).toLocaleString()}`).join('\n');
    const choice = await askPrompt(`选择会话序号：\n${options}`, '1'); const selected = sessions[Number(choice) - 1];
    if (selected) { state.conversation = selected; $('#sessionName').textContent = selected.title; await restoreMessages(selected.id); }
  } catch (error) { showError(error); }
};

function selectedModel(){return $('#modelSelect').value==='__custom__' ? ($('#customModel').value.trim()||null) : ($('#modelSelect').value||null);}
function restoreModel(model){
  const options=[...$('#modelSelect').options];if(options.some(o=>o.value===model))$('#modelSelect').value=model;
  else {$('#modelSelect').value='__custom__';$('#customModel').value=model;$('#customModel').classList.remove('hidden');} updateEffort();
}
function updateNewLabels(){
  const en=state.language==='en';const pairs={modelLabel:['模型','Model'],imageOptionText:['让模型看当前页/选区图像（远端请求）','Send page / selected image to model (remote request)'],saveCodexSettings:['保存默认模型与路径','Save default model and CLI path'],loginSteps:['查看登录步骤','Login instructions'],refreshModels:['刷新模型目录','Refresh model catalog'],testCodex:['测试连接（远端请求）','Test connection (remote request)'],reparseAll:['重新识别整篇','Reparse document'],forceOcr:['强制 OCR 当前页','Force OCR current page'],cancelParse:['取消解析任务','Cancel parsing']};
  for(const [id,values]of Object.entries(pairs))$('#'+id).textContent=values[en?1:0];
  $('#resumeParse').textContent=en?'Resume document parsing':'恢复整篇解析';$('#adapterLabel').firstChild.textContent=en?'Question adapter':'问答适配器';$('#adapterSelect').options[0].textContent=en?'app-server (real deltas)':'app-server（真实增量）';$('#adapterSelect').options[1].textContent=en?'exec (complete-answer fallback)':'exec（完整答案降级）';
  $('#cliPathLabel').firstChild.textContent=en?'Native CLI executable path':'CLI 原生可执行文件路径';
  $('#modelSelect').options[0].textContent=en?'Codex default':'Codex 默认配置';
  const custom=[...$('#modelSelect').options].find(o=>o.value==='__custom__');if(custom)custom.textContent=en?'Custom ID (unverified)':'自定义 ID（未验证）';
  $('#effortSelect').options[0].textContent=en?'Default effort':'默认推理强度';
  $('#customModel').placeholder=en?'Custom model ID (unverified)':'自定义 model ID（未验证）';
}
async function refreshModelCatalog(force=false){
  const old=selectedModel();const data=await(await api('/api/codex/models'+(force?'?refresh=true':''))).json();state.models=data.data;
  $('#modelSelect').replaceChildren(new Option(state.language==='en'?'Codex default':'Codex 默认配置',''));
  for(const m of data.data)if(!m.hidden)$('#modelSelect').add(new Option(m.displayName,m.model));
  $('#modelSelect').add(new Option(state.language==='en'?'Custom ID (unverified)':'自定义 ID（未验证）','__custom__'));
  if(old)restoreModel(old);
  $('#modelCatalogStatus').textContent=(data.error ? `${localizedError(data.error.code+': '+data.error.message)}` : `${data.data.length} models · ${data.source}`)+' · '+data.checked_at;
  updateEffort();
}
function updateEffort(){
  const m=(state.models||[]).find(m=>m.model===selectedModel()||(!selectedModel()&&m.isDefault));
  $('#effortSelect').replaceChildren(new Option(state.language==='en'?'Default effort':'默认推理强度',''));
  for(const e of m?.supportedReasoningEfforts||[])$('#effortSelect').add(new Option(e.reasoningEffort,e.reasoningEffort));
  $('#customModel').classList.toggle('hidden',$('#modelSelect').value!=='__custom__');
  $('#includePageImage').disabled=!m?.inputModalities?.includes('image');
  if($('#includePageImage').disabled)$('#includePageImage').checked=false;
}
function addAnswerDetails(bubble,data){
  const model=document.createElement('small');model.className='answer-model'; if(data.context_manifest?.parse_revision && data.context_manifest.parse_revision!==state.document?.parse_revision){const warning=document.createElement('div');warning.className='citation-warning';warning.textContent=state.language==='en'?'Source parsing revision has changed; historic quotes are retained.':'来源解析版本已更新；历史引用片段保留。';bubble.append(warning);}model.textContent=`${state.language==='en'?'Requested':'请求模型'}: ${data.requested_model||'Codex default'} · ${state.language==='en'?'Confirmed':'协议确认'}: ${data.actual_model||'未确认 / unconfirmed'}`;bubble.append(model);
  if(data.context_manifest){const details=document.createElement('details'),summary=document.createElement('summary'),pre=document.createElement('pre');summary.textContent=state.language==='en'?'Source coverage':'查看依据与解析版本';pre.textContent=JSON.stringify(data.context_manifest,null,2);details.append(summary,pre);bubble.append(details);}
}
async function startReparse(scope,force=false,resume=false){
  if(!state.document)return;
  const result=await(await api(`/api/documents/${state.document.id}/reparse`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({scope,page_number:state.page,force_ocr:force,resume})})).json();
  state.parseJob=result.job_id;
  while(state.parseJob===result.job_id){
    const job=await(await api(`/api/parse-jobs/${result.job_id}`)).json();$('#parseSummary').textContent=`${job.stage}: ${job.completed_pages}/${job.total_pages} · ${job.failed_pages} failed`;
    if(!['queued','running'].includes(job.status)){
      state.parseJob=null;state.document=await(await api(`/api/documents/${state.document.id}`)).json();state.parseRevision=state.document.parse_revision;
      await window.workbenchReader.draw(state.page,state.zoom,state.fitWidth);toast(`${job.status}: ${job.error_json}`);return;
    }
    await new Promise(resolve=>setTimeout(resolve,750));
  }
}
$('#modelSelect').onchange=async()=>{updateEffort();if(state.conversation)await api(`/api/conversations/${state.conversation.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:selectedModel(),reasoning_effort:null})});};
$('#customModel').onchange=$('#modelSelect').onchange;
$('#refreshModels').onclick=()=>refreshModelCatalog(true).catch(showError);
$('#saveCodexSettings').onclick=async()=>{try{for(const [key,value]of Object.entries({'codex.default_model':selectedModel()||'','codex.cli_path':$('#cliPath').value.trim(),'codex.adapter':$('#adapterSelect').value,'codex.default_reasoning_effort':$('#effortSelect').value}))await api('/api/settings/'+key,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({value})});await api('/api/codex/probe',{method:'POST'});await loadDiagnostics();toast(state.language==='en'?'Saved':'已保存');}catch(e){showError(e);}};
$('#loginSteps').onclick=()=>{$('#loginGuide').classList.remove('hidden');const steps=state.codex?.login_steps||['codex login','codex login --device-auth'];$('#loginGuide').textContent=(state.language==='en'?'Run the same native CLI in PowerShell:\n':'在 PowerShell 运行工作台实际使用的原生 CLI：\n')+steps.join('\n')+(state.language==='en'?'\nComplete official login yourself, then click Check environment. Desktop login does not establish CLI login.':'\n由本人完成官方登录，然后点击重新检查环境，无需重启。桌面聊天可用不代表 CLI 已登录。');};
$('#testCodex').onclick=async()=>{try{const result=await(await api('/api/codex/test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:selectedModel()})})).json();$('#diagnosticData').textContent=JSON.stringify(result,null,2);}catch(e){showError(e);}};
$('#reparseAll').onclick=()=>startReparse('all').catch(showError);
$('#reparsePage').onclick=()=>startReparse('page').catch(showError);
$('#forceOcr').onclick=()=>startReparse('page',true).catch(showError);
$('#cancelParse').onclick=()=>state.parseJob&&api(`/api/jobs/${state.parseJob}/cancel`,{method:'POST'}).catch(showError);
$('#rotatePage').onclick=()=>window.workbenchReader?.rotate(state.page,state.zoom,state.fitWidth).catch(showError);
$('#selectImage').onclick=()=>window.workbenchReader?.imageSelection();
window.addEventListener('reader-ready',()=>{if(state.document)window.workbenchReader.open(state.document.id).catch(showError);});
window.addEventListener('reader-page',e=>{state.page=e.detail.page;state.zoom=e.detail.zoom;state.parseRevision=e.detail.data.parse_revision;state.currentPageData=e.detail.data;$('#pageInput').value=state.page;$('#zoomValue').textContent=`${e.detail.zoom}%`;$('#readerStatus').textContent=`PDF ${state.page}/${state.document.page_count} · ${e.detail.data.page_kind} · ${e.detail.data.text_source} · ${e.detail.data.page_label ? 'print '+e.detail.data.page_label : ''}`;});
window.addEventListener('reader-flip',e=>{goToPage(state.page+e.detail.direction);$('#documentView').scrollTop=e.detail.direction>0?0:$('#documentView').scrollHeight;});
window.addEventListener('paper-selection',e=>{state.selectedText=e.detail.text;$('#selectionSource').textContent=`${state.currentPageData?.text_source||'text'} · revision ${e.detail.revision}`;state.selectionBlocks=e.detail.blockIds;state.parseRevision=e.detail.revision;$('#selectionPage').textContent=e.detail.page;$('#selectionText').textContent=e.detail.text;$('#contextCard').classList.remove('hidden');$('#contextMode').value='selection';});
window.addEventListener('paper-image-selection',e=>{state.imageBBox=e.detail.bbox;$('#includePageImage').checked=!$('#includePageImage').disabled;toast(state.language==='en'?'Image region selected; choose a model with image input':'已选择图像区域；需选择支持图像的模型');});
(async()=>{try{await refreshModelCatalog();const values=await(await api('/api/settings')).json();$('#cliPath').value=values['codex.cli_path']||'';$('#adapterSelect').value=values['codex.adapter']||'app-server';state.defaultModel=values['codex.default_model']||'';if(state.defaultModel)restoreModel(state.defaultModel);updateNewLabels();updateEffort();}catch(e){showError(e);}})();

$('#resumeParse').onclick=()=>startReparse('all',false,true).catch(showError);

$('#effortSelect').onchange=async()=>{if(state.conversation)try{await api(`/api/conversations/${state.conversation.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({reasoning_effort:$('#effortSelect').value||null})});}catch(e){showError(e);}};

async function stopGeneration(){
  if(state.requestId){try{await api(`/api/requests/${state.requestId}/cancel`,{method:'POST'});return;}catch{}}
  state.abortController?.abort();
}
let thumbnailObserver=null,thumbnailDocument=null;
$('#thumbnailToggle').onclick=()=>{
  if(!state.document)return;
  const drawer=$('#thumbnailDrawer');drawer.classList.toggle('hidden');$('#readerPanel').classList.toggle('has-thumbnails',!drawer.classList.contains('hidden'));
  if(thumbnailDocument!==state.document.id){
    thumbnailObserver?.disconnect();drawer.replaceChildren();thumbnailDocument=state.document.id;
    thumbnailObserver=new IntersectionObserver(entries=>{for(const entry of entries){const image=entry.target.querySelector('img');if(entry.isIntersecting)image.src=image.dataset.src;else image.removeAttribute('src');}},{root:drawer,rootMargin:'180px'});
    for(let p=1;p<=state.document.page_count;p++){const button=document.createElement('button'),image=document.createElement('img'),label=document.createElement('span');image.dataset.src=`/api/documents/${state.document.id}/pages/${p}/image?dpi=50`;image.alt=`PDF ${p}`;label.textContent=`PDF ${p}`;button.append(image,label);button.onclick=()=>goToPage(p);drawer.append(button);thumbnailObserver.observe(button);}
  }
  if(state.fitWidth)window.workbenchReader.draw(state.page,state.zoom,true).catch(showError);
};

function refreshDocumentLabels(){
  const en=state.language==='en';
  const footerMap={'工作台就绪':'Workbench ready','文献已保存在本机':'Paper saved locally'};
  const footer=$('#footerStatus');
  if(en && footerMap[footer.textContent])footer.textContent=footerMap[footer.textContent];
  if(!en){const match=Object.entries(footerMap).find(([,value])=>value===footer.textContent);if(match)footer.textContent=match[0];}
  const storage=$('.status-items span:last-child b');if(storage)storage.textContent=en?'Local SQLite':'本机 SQLite';
  if(state.document){const labels={ready:en?'Body text indexed':'有效正文已索引',partial:en?'Partially parsed':'部分页面未识别',needs_ocr:en?'OCR required':'需要 OCR'};$('#parseSummary').textContent=`${state.document.page_count} ${en?'pages':'页'} · ${labels[state.document.parse_status]||state.document.parse_status}`;}
  $('#pageInput').setAttribute('aria-label',en?'PDF page number':'PDF 当前页码');
  const tools={thumbnailToggle:['缩略图','Thumbnails'],rotatePage:['旋转','Rotate'],selectImage:['图像区域','Image region'],reparsePage:['重识别当前页','Reparse current page'],prevPage:['上一页','Previous page'],nextPage:['下一页','Next page'],bookmarkBtn:['添加书签','Add bookmark'],searchPage:['搜索文献','Search paper'],zoomOut:['缩小','Zoom out'],zoomIn:['放大','Zoom in'],fitWidth:['适应宽度','Fit width'],fullscreenBtn:['全屏','Fullscreen'],sendBtn:['发送','Send'],exportBtn:['导出 Markdown','Export Markdown'],newSessionBtn:['新建会话','New conversation']};for(const[id,words]of Object.entries(tools))$('#'+id).title=words[en?1:0];
  const indexMap={'已完成':'Completed','扫描件':'Scanned','部分完成':'Partial','待开始':'Pending'};
  const index=$('#indexStatus');if(en&&indexMap[index.textContent])index.textContent=indexMap[index.textContent];
  if(!en){const match=Object.entries(indexMap).find(([,value])=>value===index.textContent);if(match)index.textContent=match[0];}
  const ocrMap={'Tesseract 可用':'Tesseract available','已运行':'OCR completed','无需 OCR':'OCR not needed','部分完成':'Partial OCR','未安装 OCR':'OCR missing','缺少 Tesseract':'Tesseract missing','OCR 失败':'OCR failed'};
  if(en&&ocrMap[$('#ocrStatus').textContent])$('#ocrStatus').textContent=ocrMap[$('#ocrStatus').textContent];
  if(!en){const reverse=Object.fromEntries(Object.entries(ocrMap).map(([a,b])=>[b,a]));if(reverse[$('#ocrStatus').textContent])$('#ocrStatus').textContent=reverse[$('#ocrStatus').textContent];}
  if(!$('#loginGuide').classList.contains('hidden'))$('#loginSteps').onclick();
  const fields=$$('.status-items>span');if(fields[0])fields[0].firstChild.textContent=en?'Parsing: ':'解析：';if(fields[1])fields[1].firstChild.textContent=en?'Index: ':'索引：';if(fields[2])fields[2].firstChild.textContent=en?'Storage: ':'数据：';
}
