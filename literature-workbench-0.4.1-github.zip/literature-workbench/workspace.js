/* Reading records are local. All server mutations use the existing API. */
const words=(zh,en)=>state.language==='en'?en:zh;
function workbenchDialog(message,value=null){
  return new Promise(resolve=>{
    const previousFocus=document.activeElement,root=document.createElement('div');root.className='modal-backdrop input-dialog';
    const box=document.createElement('section');box.className='library-modal';box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');
    const label=document.createElement('label');label.textContent=message;label.className='dialog-label';
    const input=document.createElement('textarea');input.value=value??'';input.rows=3;input.maxLength=30000;input.setAttribute('aria-label',message);
    box.append(label);if(value!==null)box.append(input);
    const buttons=document.createElement('div');buttons.className='record-actions';
    const finish=result=>{root.remove();document.removeEventListener('keydown',keyboard,true);previousFocus?.focus();resolve(result);};
    const keyboard=e=>{if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();finish(null);}if(e.key==='Tab'){const items=[...box.querySelectorAll('textarea,button')];if(e.shiftKey&&document.activeElement===items[0]){e.preventDefault();items.at(-1).focus();}else if(!e.shiftKey&&document.activeElement===items.at(-1)){e.preventDefault();items[0].focus();}}};
    buttons.append(action(words('取消','Cancel'),()=>finish(null)),action(words('确定','Confirm'),()=>finish(value===null?true:input.value)));
    box.append(buttons);root.append(box);document.body.append(root);document.addEventListener('keydown',keyboard,true);(value===null?buttons.firstChild:input).focus();
  });
}
async function askPrompt(message,value=''){return workbenchDialog(message,value);}
async function askConfirm(message){return (await workbenchDialog(message))===true;}
function action(text,run){const b=document.createElement('button');b.type='button';b.textContent=text;b.onclick=()=>Promise.resolve().then(run).catch(showError);return b;}
function panel(id,title){
  const root=document.createElement('div');root.id=id;root.className='modal-backdrop hidden';
  const box=document.createElement('section');box.className='library-modal';box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');
  const head=document.createElement('header'),h=document.createElement('h2');h.textContent=title;
  head.append(h,action('×',()=>root.classList.add('hidden')));box.append(head);root.append(box);document.body.append(root);
  root.addEventListener('click',e=>{if(e.target===root)root.classList.add('hidden');});return {root,box,h};
}
const records=panel('recordsModal','阅读记录'),sessions=panel('sessionsModal','会话管理');
const recordsBody=document.createElement('div');records.box.append(recordsBody);
const sessionsBody=document.createElement('div');sessions.box.append(sessionsBody);
const recordButton=action('笔记 / 书签',()=>showRecords());recordButton.id='recordsBtn';recordButton.className='ghost-btn';$('#libraryBtn').after(recordButton);
const sessionButton=action('会话',()=>showSessions());sessionButton.id='sessionsBtn';sessionButton.className='link-btn';$('#renameBtn').after(sessionButton);
$('#sessionName').onclick=()=>showSessions().catch(showError);
const fitPage=action('▢',()=>{state.fitWidth='page';goToPage(state.page);});fitPage.id='fitPage';fitPage.className='tool-btn';fitPage.title='适应页面 / Fit page';$('#fitWidth').after(fitPage);
const modeSelect=document.createElement('select');modeSelect.id='readingMode';modeSelect.setAttribute('aria-label','阅读模式 / Reading mode');
modeSelect.append(new Option('单页','single'),new Option('连续','continuous'));$('#readerPanel .reader-left').append(modeSelect);
modeSelect.onchange=()=>window.workbenchReader?.setContinuous(modeSelect.value==='continuous')?.catch(showError);
async function downloadFile(url,name){const response=await api(url),blob=await response.blob(),link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(link.href),1000);}
function row(title,detail){const item=document.createElement('article');item.className='record-row';const h=document.createElement('strong'),p=document.createElement('p');h.textContent=title;p.textContent=detail;item.append(h,p);return item;}
function empty(root){const p=document.createElement('p');p.className='empty-state';p.textContent=words('暂无记录','No records yet');root.append(p);}
async function showRecords(){
  if(!state.document)return toast(words('请先打开文献','Open a document first'));
  const docId=state.document.id;records.root.classList.remove('hidden');records.h.textContent=words('阅读笔记与书签','Reading notes and bookmarks');recordsBody.textContent=words('正在读取…','Loading…');
  const [notes,marks]=await Promise.all([api(`/api/documents/${docId}/annotations`).then(r=>r.json()),api(`/api/documents/${docId}/bookmarks`).then(r=>r.json())]);
  if(docId!==state.document?.id)return;recordsBody.replaceChildren();
  const controls=document.createElement('div');controls.className='record-actions';
  controls.append(action(words('添加当前页书签','Bookmark current page'),async()=>{await createBookmark();await showRecords();}),action(words('导出笔记 Markdown','Export notes Markdown'),()=>downloadFile(`/api/documents/${docId}/notes.md`,'reading-notes.md')));recordsBody.append(controls);
  if(!notes.length&&!marks.length)empty(recordsBody);
  for(const mark of marks){const item=row(`☆ PDF ${mark.page_number}`,mark.label);item.append(action(words('跳转','Go to'),()=>{goToPage(mark.page_number);records.root.classList.add('hidden');}),action(words('删除书签','Delete bookmark'),async()=>{await api(`/api/bookmarks/${mark.id}`,{method:'DELETE'});await loadBookmarks();await showRecords();}));recordsBody.append(item);}
  for(const note of notes){const item=row(`✎ PDF ${note.page_number}`,note.selected_text);const input=document.createElement('textarea');input.value=note.note;input.rows=3;input.maxLength=30000;input.setAttribute('aria-label',words('批注内容','Note text'));
    item.append(input,action(words('保存修改','Save changes'),async()=>{await api(`/api/annotations/${note.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({note:input.value,color:note.color})});toast(words('已保存','Saved'));}),action(words('定位原文','Locate source'),()=>{window.workbenchReader.pendingQuote=note.selected_text;goToPage(note.page_number);records.root.classList.add('hidden');}),action(words('删除批注','Delete note'),async()=>{if(!await askConfirm(words('删除这条批注？','Delete this note?')))return;await api(`/api/annotations/${note.id}`,{method:'DELETE'});await showRecords();}));recordsBody.append(item);}
}
async function showSessions(){
  if(state.abortController)return toast(words('请先停止生成再切换会话','Stop generation before switching sessions'));
  if(!state.document)return toast(words('请先打开文献','Open a document first'));
  const docId=state.document.id;sessions.h.textContent=words('文献会话 · 自动保存','Document sessions · automatically saved');sessions.root.classList.remove('hidden');sessionsBody.textContent=words('正在读取…','Loading…');
  const list=await(await api(`/api/conversations?document_id=${encodeURIComponent(docId)}`)).json();if(docId!==state.document?.id)return;sessionsBody.replaceChildren();
  if(!list.length)empty(sessionsBody);
  for(const session of list){const item=row((session.id===state.conversation?.id?'● ':'')+session.title,new Date(session.updated_at).toLocaleString());
    item.append(action(words('打开','Open'),async()=>{if(state.abortController)return;state.conversation=session;restoreModel(session.model||'');$('#effortSelect').value=session.reasoning_effort||'';$('#sessionName').textContent=session.title;await restoreMessages(session.id);sessions.root.classList.add('hidden');}),action(words('导出','Export'),()=>downloadFile(`/api/conversations/${session.id}/export.md`,'conversation.md')),action(words('清空消息','Clear messages'),async()=>{if(!await askConfirm(words('清空此会话全部消息及引用？','Clear all messages and citations?')))return;await api(`/api/conversations/${session.id}/messages`,{method:'DELETE'});if(state.conversation?.id===session.id)await restoreMessages(session.id);await showSessions();}),action(words('删除会话','Delete session'),async()=>{if(!await askConfirm(words('删除此会话及全部消息？','Delete this session and all messages?')))return;await api(`/api/conversations/${session.id}`,{method:'DELETE'});if(state.conversation?.id===session.id){state.conversation=null;await createConversation(docId);}await showSessions();}));sessionsBody.append(item);
  }
}
// A saved position is per PDF; it does not alter the source file.
window.addEventListener('reader-page',e=>{
  if(!state.document)return;
  localStorage.setItem('reading-position:'+state.document.id,JSON.stringify({page:e.detail.page,zoom:e.detail.zoom,fit:state.fitWidth}));
  $$('#thumbnailDrawer button').forEach((b,i)=>b.classList.toggle('active',i+1===e.detail.page));
});
const oldRestore=restoreMessages;
restoreMessages=async function(id){await oldRestore(id);if(state.conversation?.id!==id)return;decorateMessages();};
function decorateMessages(){
  $$('.message.assistant').forEach(message=>{
    if(message.querySelector('.answer-actions'))return;const bubble=message.querySelector('.bubble'),bar=document.createElement('div');bar.className='answer-actions';
    bar.append(action(words('复制回答','Copy answer'),async()=>{const clone=bubble.cloneNode(true);clone.querySelectorAll('details,.answer-model').forEach(n=>n.remove());await navigator.clipboard.writeText(clone.innerText||clone.textContent);toast(words('已复制','Copied'));}));
    const previous=message.previousElementSibling;
    if(previous?.classList.contains('user'))bar.append(action(words('重新提问','Ask again'),()=>{if(state.abortController)return;$('#questionInput').value=previous.querySelector('.bubble').textContent;$('#questionInput').focus();toast(words('已填入原问题，将使用当前上下文；历史回答保留','Question restored; current context will be used. Previous answers are retained.'));}));
    message.append(bar);
  });
}
new MutationObserver(()=>{if(!state.abortController)decorateMessages();}).observe($('#chatFeed'),{childList:true,subtree:true});
// Accept a new file while another PDF is open, without navigating the browser away.
document.addEventListener('dragover',e=>{if([...e.dataTransfer.types].includes('Files'))e.preventDefault();});
document.addEventListener('drop',e=>{if(e.target.closest('#dropZone'))return;if(e.dataTransfer.files.length){e.preventDefault();openPdf(e.dataTransfer.files).catch(showError);}});
document.addEventListener('keydown',e=>{if(e.key==='Escape')$$('.modal-backdrop').forEach(m=>m.classList.add('hidden'));});
const previousLanguage=setLanguage;
setLanguage=function(language){previousLanguage(language);recordButton.textContent=words('笔记 / 书签','Notes / bookmarks');sessionButton.textContent=words('会话','Sessions');modeSelect.options[0].textContent=words('单页','Single');modeSelect.options[1].textContent=words('连续','Continuous');};
setLanguage(state.language);

// Keep source actions available without hiding them in a prompt menu.
const extraActions=document.createElement('div');extraActions.className='context-extra-actions';$('#contextCard').append(extraActions);
const passageActions=[['翻译','Translate','请将选中文本翻译成中文，保留术语并标明歧义。','Translate the selected passage into English, preserving technical terms and ambiguities.'],['解释公式','Explain formula','请解释选中公式的符号、假设和推导，区分原文与推断；识别不清时明确说明。','Explain the selected formula, symbols, assumptions and derivation; distinguish evidence from inference and flag transcription uncertainty.'],['解释方法','Explain method','请解释这段中的研究方法、输入、输出及适用条件。','Explain the method, inputs, outputs and applicability in this passage.'],['质疑论证','Critique','请检查这段论证的逻辑、证据和局限，区分作者表述和你的判断。','Critique the logic, evidence and limitations, separating author claims from your assessment.'],['与全文联系','Connect to paper','请结合检索到的全文上下文解释这段文字的作用：','Explain this passage using retrieved paper context: ']];
function labelPassageActions(){extraActions.replaceChildren();for(const [zh,en,qzh,qen]of passageActions){extraActions.append(action(words(zh,en),()=>{const full=zh==='与全文联系';if(full)$('#contextMode').value='fulltext';return sendQuestion(words(qzh,qen)+(full?'\n'+state.selectedText:''));}));}}
labelPassageActions();
$('#langBtn').addEventListener('click',labelPassageActions);
// In continuous mode a scroll can change the source page without a toolbar click.
let lastSourcePage=null;
window.addEventListener('reader-page',e=>{
  if(lastSourcePage!==null&&lastSourcePage!==e.detail.page){state.selectedText='';state.selectionBlocks=[];state.imageBBox=null;$('#contextCard').classList.add('hidden');$('#pageTextDrawer').classList.add('hidden');}
  lastSourcePage=e.detail.page;
});
const originalNewSession=$('#newSessionBtn').onclick;
$('#newSessionBtn').onclick=()=>{if(state.abortController)return toast(words('请先停止生成','Stop generation first'));return originalNewSession();};
